import requests
import json
import logging
from model import Settings
from django.conf import settings

class RequestServer:
    """
    Classe para realizar requisições HTTP utilizando a biblioteca requests. 
    Inclui suporte para autenticação via token e métodos HTTP padrão.
    """

    def __init__(self):
        """
        Inicializa a classe com URL base e configurações opcionais de autenticação.

        Args:
            base_path (str): O URL base para todas as requisições.
            token (str, opcional): Token de autenticação (ex.: JWT).
            typeToken (str, opcional): Tipo do token de autenticação (ex.: 'Bearer').
        """
        self.session = requests.Session()
        self.headers = {
            'Accept': 'application/json',
            'User-Agent': 'ZDAC/3.0'
        }
        self.settings = Settings.objects.first()
        self.api_key = self.settings.key if self.settings and self.settings.key else None
        self.api_host = self.settings.host if self.settings and self.settings.host else None        
        self.api_header_name = 'x-api-key'
        self.base_path = ''
        
        if self.api_host:
            self.base_path = self.ensure_http_prefix(self.api_host)
           
        if self.api_key:
            self.headers[self.api_header_name] = self.api_key
    
    def __enter__(self):
        """
        Permite que a classe seja usada em um contexto 'with'.

        Returns:
            HttpService: Retorna a própria instância.
        """
        return self
    
    def __exit__(self, exc_type, exc_value, traceback):
        """
        Garante o fechamento da sessão HTTP ao sair do contexto 'with'.

        Args:
            exc_type (type): Tipo da exceção (se houver).
            exc_value (Exception): Instância da exceção (se houver).
            traceback (traceback): Rastreamento da exceção (se houver).
        """
        self.session.close()
    
    def close(self):
        """
        Fecha a sessão HTTP manualmente.
        """
        self.session.close()
    
    @staticmethod
    def ensure_http_prefix(url):
        """
        Adiciona o prefixo 'http://' ao URL se necessário.

        Args:
            url (str): O URL a ser ajustado.

        Returns:
            str: O URL ajustado com 'http://' ou 'https://'.
        """
        if url:        
            if not url.startswith('http://') and not url.startswith('https://'):
                return f'http://{url}' if settings.DEBUD else f'https://{url}'
            else:
                return url
        else:
            return ''
    
    def ensure_leading_slash(self, path):
        """
        Adiciona uma barra inicial ao caminho se necessário.

        Args:
            path (str): O caminho a ser ajustado.

        Returns:
            str: O caminho ajustado.
        """
        if not path:
            return ''
        
        if path.startswith(('http://', 'https://')):
            return path
        else:
            if not self.base_path.endswith('/') and not path.startswith('/'):
                path = '/' + path
            return path
    
    def request(self, method, path=None, data=None, headers=None, files=None, **kwargs):
        """
        Realiza uma requisição HTTP genérica.

        Args:
            method (str): O método HTTP a ser usado (ex.: 'get', 'post').
            path (str): O caminho ou URL para a requisição.
            data (dict, opcional): Dados a serem enviados no corpo da requisição.
            headers (dict, opcional): Cabeçalhos adicionais para a requisição.
            files (dict, opcional): Arquivos para upload (multipart/form-data).
            **kwargs: Parâmetros adicionais suportados por requests.

        Returns:
            requests.Response or None: A resposta da requisição, ou None em caso de erro.
        """
        url = f'{self.base_path}{self.ensure_leading_slash(path)}'
        
        json_data = None
        
        if data and not files:
            self.headers['Content-Type'] = 'application/json; charset=utf-8'
            json_data = json.dumps(data)
        elif files:
            self.headers['Content-Type'] = 'multipart/form-data'
        
        client_method = getattr(self.session, method.lower(), None)
        
        if client_method:
            return client_method(url, data=json_data, headers=headers or self.headers, files=files, **kwargs)
            # response.raise_for_status()
            # return response
            # try:
            #     return response
            # except Exception as ce:
            #     logging.error(f"Erro de conexão: {ce}")
        else:
            logging.error(f"Método {method} não encontrado")
            return None
    
    def get(self, path, **kwargs):
        """
        Realiza uma requisição HTTP GET.

        Args:
            path (str): O caminho ou URL para a requisição.
            **kwargs: Parâmetros adicionais suportados por requests.

        Returns:
            requests.Response or None: A resposta da requisição, ou None em caso de erro.
        """
        return self.request('get', path, **kwargs)
            
    def post(self, path, data=None, files=None, **kwargs):
        """
        Realiza uma requisição HTTP POST.

        Args:
            path (str): O caminho ou URL para a requisição.
            data (dict, opcional): Dados a serem enviados no corpo da requisição.
            files (dict, opcional): Arquivos para upload (multipart/form-data).
            **kwargs: Parâmetros adicionais suportados por requests.

        Returns:
            requests.Response or None: A resposta da requisição, ou None em caso de erro.
        """
        return self.request('post', path, data=data, files=files, **kwargs)
    
    def put(self, path, data=None, files=None, **kwargs):
        """
        Realiza uma requisição HTTP PUT.

        Args:
            path (str): O caminho ou URL para a requisição.
            data (dict, opcional): Dados a serem enviados no corpo da requisição.
            files (dict, opcional): Arquivos para upload (multipart/form-data).
            **kwargs: Parâmetros adicionais suportados por requests.

        Returns:
            requests.Response or None: A resposta da requisição, ou None em caso de erro.
        """
        return self.request('put', path, data=data, files=files, **kwargs)
    
    def delete(self, path, **kwargs):
        """
        Realiza uma requisição HTTP DELETE.

        Args:
            path (str): O caminho ou URL para a requisição.
            **kwargs: Parâmetros adicionais suportados por requests.

        Returns:
            requests.Response or None: A resposta da requisição, ou None em caso de erro.
        """
        return self.request('delete', path, **kwargs)
    
    def patch(self, path, data=None, files=None, **kwargs):
        """
        Realiza uma requisição HTTP PATCH.

        Args:
            path (str): O caminho ou URL para a requisição.
            data (dict, opcional): Dados a serem enviados no corpo da requisição.
            files (dict, opcional): Arquivos para upload (multipart/form-data).
            **kwargs: Parâmetros adicionais suportados por requests.

        Returns:
            requests.Response or None: A resposta da requisição, ou None em caso de erro.
        """
        return self.request('patch', path, data=data, files=files, **kwargs)
    
    def head(self, path, **kwargs):
        """
        Realiza uma requisição HTTP HEAD.

        Args:
            path (str): O caminho ou URL para a requisição.
            **kwargs: Parâmetros adicionais suportados por requests.

        Returns:
            requests.Response or None: A resposta da requisição, ou None em caso de erro.
        """
        return self.request('head', path, **kwargs)
    
    def options(self, path, **kwargs):
        """
        Realiza uma requisição HTTP OPTIONS.

        Args:
            path (str): O caminho ou URL para a requisição.
            **kwargs: Parâmetros adicionais suportados por requests.

        Returns:
            requests.Response or None: A resposta da requisição, ou None em caso de erro.
        """
        return self.request('options', path, **kwargs)
    
    def trace(self, path, **kwargs):
        """
        Realiza uma requisição HTTP TRACE.

        Args:
            path (str): O caminho ou URL para a requisição.
            **kwargs: Parâmetros adicionais suportados por requests.

        Returns:
            requests.Response or None: A resposta da requisição, ou None em caso de erro.
        """
        return self.request('trace', path, **kwargs)

