from django.urls import path, include
from rest_framework.routers import DefaultRouter
from backend.views.controller import (SensorViweSet, ReadingViewSet, SettingsViewSet, CustomAuthToken,LogoutView, ChangePasswordView, ResetPasswordView, VerifyTokenView )

routes = DefaultRouter()
routes.register(r'sensors', SensorViweSet, basename='sensors')
routes.register(r'readings', ReadingViewSet, basename='readings')
routes.register(r'settings', SettingsViewSet, basename='settings')

urlpatterns_routes = [
    path('', include(routes.urls)),
    path('token/', CustomAuthToken.as_view(), name='token_obtain_pair'),
    path('token/verify/', VerifyTokenView.as_view(), name='token_verify'),
    path('token/delete/', LogoutView.as_view(), name='token_delete'),
    path('password/update/', ChangePasswordView.as_view(), name='password_update'),
    path('password/reset/', ResetPasswordView.as_view(), name='password_reset'),
] 

urlpatterns = [
    path('api/', include(urlpatterns_routes)),
]
