from rest_framework import serializers
from django.contrib.auth.models import User
from database.models import Reading, Sensor, Settings, SensorMetrics

class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        exclude = ['password']

class ChangePasswordSerializer(serializers.Serializer):
    current_password = serializers.CharField(required=True)
    new_password = serializers.CharField(required=True)

    def validate_current_password(self, value):
        user = self.context['request'].user
        if not user.check_password(value):
            raise serializers.ValidationError('Current password is incorrect')
        return value

    def validate_new_password(self, value):
        # Adicione aqui quaisquer validações adicionais para a nova senha
        return value

class SettingsSerializer(serializers.ModelSerializer):
    class Meta:
        model = Settings
        fields = '__all__'

class SensorMetricsSerializer(serializers.ModelSerializer):
    class Meta:
        model = SensorMetrics
        fields = '__all__'

class SensorSerializer(serializers.ModelSerializer):
    status = serializers.SerializerMethodField()
    class Meta:
        model = Sensor
        fields = '__all__'
        extra_fields = ['status']

    def get_status(self, obj):
        try:
            status = SensorMetrics.objects.filter(sensor=obj.code).first()
            if status:
                return SensorMetricsSerializer(status).data
            return None
        except Exception as e:
            return None

class ReadingSerializer(serializers.ModelSerializer):
    class Meta:
        model = Reading
        fields = '__all__'
