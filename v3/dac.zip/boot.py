import logging
import datetime
import subprocess
import threading
import time
from enum import Enum
from typing import Optional, Dict, Any, Callable
from dataclasses import dataclass
from contextlib import contextmanager
from django.utils import timezone # type: ignore
from model import Settings, Sensor, TriggerExecution
from server_request import RequestServer
from helps import get_mac_address, mac_to_hex

logger = logging.getLogger(__name__)

class TriggerStatus(Enum):
    PENDING = 'pending'
    EXECUTING = 'executing'
    SUCCESS = 'success'
    ERROR = 'error'
    DUPLICATE = 'duplicate'

@dataclass
class TriggerResult:
    status: TriggerStatus
    result: Any = None
    error_message: Optional[str] = None


class DacBoot:
    """
    Main DAC boot controller responsible for:
    - Auto-restart scheduling
    - Remote trigger execution with deduplication
    - Webhook notifications with retry logic
    """
    
    TRIGGER_CHECK_INTERVAL = 10
    AUTO_RESTART_CHECK_INTERVAL = 10
    MAIN_LOOP_INTERVAL = 1
    TRIGGER_EXPIRATION_HOURS = 24
    
    def __init__(self):
        self.running = True
        self.http = RequestServer()
        self.next_auto_restart_check = 0
        self.next_trigger_check = 0
        
        self.last_reboot_date = None

        self.trigger_handlers: Dict[str, Callable] = {
            'trigger_test':self._handle_trigger_test,
            'reboot': self._handle_reboot,
            'update_settings': self._handle_update_settings,
            'delete_sensor': self._handle_delete_sensor,
            'create_sensor': self._handle_create_sensor,
            'update_sensor': self._handle_update_sensor,
        }
        
        self._initialize_settings()
        self._cleanup_old_trigger_executions()

    def _initialize_settings(self) -> None:
        """Ensures settings exist, creates default if missing"""
        try:
            self.settings = Settings.objects.first()
            if not self.settings:
                logger.warning('No settings found, creating default')
                self.settings = Settings.createNewSettings()
        except Exception as e:
            logger.error(f'Failed to initialize settings: {e}')
            raise

    def _cleanup_old_trigger_executions(self) -> None:
        """Remove trigger execution records older than 24 hours"""
        try:
            expiration_time = timezone.now() - datetime.timedelta(
                hours=self.TRIGGER_EXPIRATION_HOURS
            )
            deleted_count = TriggerExecution.objects.filter(
                created_at__lt=expiration_time
            ).delete()[0]
            
            if deleted_count > 0:
                logger.info(f'Cleaned up {deleted_count} old trigger executions')
        except Exception as e:
            logger.error(f'Failed to cleanup old triggers: {e}')

    def _is_trigger_duplicate(self, trigger_id: str, trigger_name: str) -> bool:
        """Check if trigger was already executed to prevent duplicates"""
        try:
            return TriggerExecution.objects.filter(
                trigger_id=trigger_id,
                trigger_name=trigger_name,
                status__in=[TriggerStatus.EXECUTING.value, TriggerStatus.SUCCESS.value]
            ).exists()
        except Exception as e:
            logger.error(f'Error checking trigger duplicate: {e}')
            return False

    def _register_trigger_execution(
        self, 
        trigger_id: str, 
        trigger_name: str,
        status: TriggerStatus,
        payload: Optional[Dict] = None,
        result: Any = None,
        error_message: Optional[str] = None
    ) -> None:
        """Register trigger execution in database for deduplication"""
        try:
            TriggerExecution.objects.create(
                trigger_id=trigger_id,
                trigger_name=trigger_name,
                status=status.value,
                payload=payload or {},
                result=result,
                error_message=error_message,
                executed_at=timezone.now()
            )
        except Exception as e:
            logger.error(f'Failed to register trigger execution: {e}')

    @contextmanager
    def _trigger_execution_context(self, trigger_id: str, trigger_name: str, payload: Dict):
        """Context manager for trigger execution with automatic status tracking"""
        self._register_trigger_execution(
            trigger_id, 
            trigger_name, 
            TriggerStatus.EXECUTING,
            payload=payload
        )
        
        try:
            yield
        except Exception as e:
            self._register_trigger_execution(
                trigger_id,
                trigger_name,
                TriggerStatus.ERROR,
                payload=payload,
                error_message=str(e)
            )
            raise
        else:
            self._register_trigger_execution(
                trigger_id,
                trigger_name,
                TriggerStatus.SUCCESS,
                payload=payload
            )

    def _run_async_command(self, command: list) -> None:
        """Execute system command asynchronously without blocking"""
        def _execute():
            try:
                result = subprocess.run(
                    command,
                    check=False,
                    capture_output=True,
                    text=True,
                    timeout=30
                )
                if result.returncode != 0:
                    logger.error(f'Command failed: {result.stderr}')
            except subprocess.TimeoutExpired:
                logger.error(f'Command timeout: {" ".join(command)}')
            except Exception as e:
                logger.error(f'Command execution error: {e}')

        thread = threading.Thread(target=_execute, daemon=True)
        thread.start()

    def _send_webhook(
        self, 
        trigger: str, 
        payload: Dict[str, Any],
        retry_count: int = 3
    ) -> bool:
        """Send webhook with retry logic"""

        if not self.settings.server_url or self.settings.server_key:
            return False

        data = {
            'trigger': trigger,
            'payload': payload,
        }
        
        for attempt in range(retry_count):
            try:
                mac = mac_to_hex(get_mac_address())
                response = self.http.post(f'dac/webhook/{mac}', data=data, timeout=10)
                if response and response.ok:
                    return True
                    
                logger.warning(f'Webhook attempt {attempt + 1} failed with status: {response.status_code if response else "no response"}')
                
            except Exception as e:
                logger.error(f'Webhook attempt {attempt + 1} error: {e}')
            
            if attempt < retry_count - 1:
                time.sleep(2 ** attempt)  # Exponential backoff
        
        return False

    def auto_reboot(self) -> None:
        """Check and execute scheduled auto-restart with persistent storage protection"""
        now_ts = time.time()
        if now_ts < self.next_auto_restart_check:
            return
        
        self.next_auto_restart_check = now_ts + self.AUTO_RESTART_CHECK_INTERVAL

        try:
            settings = Settings.objects.first()
            if not settings:
                settings = Settings.createNewSettings

            # 1. Validações de configuração
            auto_enabled = settings.getJson('meta.auto_restart', False)
            restart_time = settings.getJson('meta.auto_restart_time')
            
            if not auto_enabled or not restart_time:
                return

            # --- CORREÇÃO AQUI ---
            # Captura o momento atual e converte para o Timezone local (America/Sao_Paulo)
            # Isso garante que tanto a data quanto a hora estejam alinhadas com o relógio do Brasil
            local_now = timezone.localtime() 
            
            current_date_str = local_now.strftime('%Y-%m-%d')
            current_time_str = local_now.strftime('%H:%M')
            # ---------------------

            # 2. Verificação de Persistência (Banco de Dados)
            last_restart_date = settings.getJson('meta.last_auto_restart_date')
            
            # SE a data salva for igual a data local de hoje, aborta.
            if last_restart_date == current_date_str:
                return 

            # 3. Verificação de Horário
            # Agora compara maçãs com maçãs (Hora Local vs Hora Configurada)
            if current_time_str == restart_time:
                logger.info(f'Scheduled time match ({current_time_str}). Initiating auto-restart sequence.')
                
                # Salva a data LOCAL para evitar loop
                settings.setJson('meta.last_auto_restart_date', current_date_str, True)
                
                payload = {
                    'status': TriggerStatus.EXECUTING.value,
                    'datetime': local_now.strftime('%Y-%m-%d %H:%M:%S'), # Log com hora local
                    'reason': 'scheduled_restart'
                }
                
                try:
                    self._send_webhook('auto_reboot', payload=payload)
                except Exception as e:
                    logger.error(f"Failed to send webhook before reboot: {e}")

                time.sleep(2)

                self._run_async_command(["/usr/bin/sudo", "reboot"])
                
        except Exception as e:
            logger.error(f'Auto-reboot check failed: {e}')


    def _handle_trigger_test(self, data: Dict[str, Any]) -> TriggerResult:
        """Handle trigger test trigger"""
        try:
            payload = {
                'status': TriggerStatus.SUCCESS.value,
                'datetime': timezone.now().strftime('%Y-%m-%d %H:%M:%S'),
                'reason': 'manual_trigger'
            }
            self._send_webhook('trigger_test', payload)
            logger.warning(f"trigger_test: {payload.values}")
            self._run_async_command(["echo", f"trigger_test: {payload.values}"])
            return TriggerResult(status=TriggerStatus.SUCCESS)

        except Exception as e:
            return TriggerResult(
                status=TriggerStatus.ERROR,
                error_message=str(e)
            )


    def _handle_reboot(self, data: Dict[str, Any]) -> TriggerResult:
        """Handle system reboot trigger"""
        try:
            payload = {
                'status': TriggerStatus.EXECUTING.value,
                'datetime': timezone.now().strftime('%Y-%m-%d %H:%M:%S'),
                'reason': 'manual_trigger'
            }
            self._send_webhook('reboot', payload)
            self._run_async_command(["/usr/bin/sudo", "reboot"])
            
            return TriggerResult(status=TriggerStatus.SUCCESS)
        except Exception as e:
            return TriggerResult(
                status=TriggerStatus.ERROR,
                error_message=str(e)
            )

    def _handle_update_settings(self, data: Dict[str, Any]) -> TriggerResult:
        """Handle settings update trigger"""
        try:
            settings = Settings.objects.first()
            if not settings:
                return TriggerResult(
                    status=TriggerStatus.ERROR,
                    error_message='Settings object not found'
                )

            # Update primary fields
            if 'host' in data:
                settings.host = data['host']
            if 'key' in data:
                settings.key = data['key']
            
            # Update meta fields
            for key, value in data.items():
                if key not in ['host', 'key']:
                    settings.setJson(f'meta.{key}', value)
            
            settings.save()
            return TriggerResult(status=TriggerStatus.SUCCESS)
            
        except Exception as e:
            return TriggerResult(
                status=TriggerStatus.ERROR,
                error_message=str(e)
            )

    def _handle_delete_sensor(self, data: Dict[str, Any]) -> TriggerResult:
        """Handle sensor deletion trigger"""
        try:
            sensor_data = data.get('sensor', {})
            if not sensor_data:
                return TriggerResult(
                    status=TriggerStatus.ERROR,
                    error_message='Missing sensor data'
                )

            sensor_code = sensor_data.get('code')
            if not sensor_code:
                return TriggerResult(
                    status=TriggerStatus.ERROR,
                    error_message='Missing sensor code'
                )

            sensor = Sensor.objects.filter(code=sensor_code).first()
            if not sensor:
                return TriggerResult(
                    status=TriggerStatus.ERROR,
                    error_message=f'Sensor not found: {sensor_code}'
                )

            sensor.delete()
            return TriggerResult(
                status=TriggerStatus.SUCCESS,
                result={'deleted_code': sensor_code}
            )
            
        except Exception as e:
            return TriggerResult(
                status=TriggerStatus.ERROR,
                error_message=str(e)
            )

    def _handle_create_sensor(self, data: Dict[str, Any]) -> TriggerResult:
        """Handle sensor creation trigger"""
        try:
            sensor_data = data.get('sensor', {})
            if not sensor_data:
                return TriggerResult(
                    status=TriggerStatus.ERROR,
                    error_message='Missing sensor data'
                )

            required_fields = ['name']
            missing_fields = [f for f in required_fields if f not in sensor_data]
            if missing_fields:
                return TriggerResult(
                    status=TriggerStatus.ERROR,
                    error_message=f'Missing required fields: {", ".join(missing_fields)}'
                )

            sensor = Sensor.objects.create(
                name=sensor_data.get('name'),
                description=sensor_data.get('description', ''),
                active=sensor_data.get('active', False),
                kind=sensor_data.get('kind', 'modbus'),
                meta=sensor_data.get('meta', {})
            )
            
            return TriggerResult(
                status=TriggerStatus.SUCCESS,
                result={'created_code': sensor.code}
            )
            
        except Exception as e:
            return TriggerResult(
                status=TriggerStatus.ERROR,
                error_message=str(e)
            )

    def _handle_update_sensor(self, data: Dict[str, Any]) -> TriggerResult:
        """Handle sensor update trigger"""
        try:
            sensor_data = data.get('sensor', {})
            if not sensor_data:
                return TriggerResult(
                    status=TriggerStatus.ERROR,
                    error_message='Missing sensor data'
                )

            sensor_code = sensor_data.get('code')
            if not sensor_code:
                return TriggerResult(
                    status=TriggerStatus.ERROR,
                    error_message='Missing sensor code'
                )

            sensor = Sensor.objects.filter(code=sensor_code).first()
            if not sensor:
                return TriggerResult(
                    status=TriggerStatus.ERROR,
                    error_message=f'Sensor not found: {sensor_code}'
                )

            # Update fields
            sensor.name = sensor_data.get('name', sensor.name)
            sensor.description = sensor_data.get('description', sensor.description)
            sensor.active = sensor_data.get('active', sensor.active)
            sensor.kind = sensor_data.get('kind', sensor.kind)
            sensor.meta = sensor_data.get('meta', sensor.meta)
            sensor.save()
            
            return TriggerResult(
                status=TriggerStatus.SUCCESS,
                result={'updated_code': sensor_code}
            )
            
        except Exception as e:
            return TriggerResult(
                status=TriggerStatus.ERROR,
                error_message=str(e)
            )

    def check_and_execute_triggers(self) -> None:
        """Fetch and execute pending triggers from server"""
        
        if not self.settings.host or self.settings.key:
            return
        
        now = time.time()
        if now < self.next_trigger_check:
            return

        self.next_trigger_check = now + self.TRIGGER_CHECK_INTERVAL

        try:
            mac = mac_to_hex(get_mac_address())
            response = self.http.get(f'dac/triggers/{mac}', timeout=10)

            if not response or response.status_code == 204:
                return
            elif response.status_code == 200:                
                response_data = response.json()
                triggers = response_data.get('triggers', [])
            
                if not triggers:
                    return

                logger.info(f'Processing {len(triggers)} trigger(s)')

                for trigger in triggers:
                    self._process_trigger(trigger)
            else:
                logger.warning(f'Failed to fetch triggers: {response.status_code}')
                return

        except Exception as e:
            logger.error(f'Trigger check failed: {e}')
            self._send_webhook(
                'check_triggers_error',
                {
                    'status': TriggerStatus.ERROR.value,
                    'datetime': timezone.now().strftime('%Y-%m-%d %H:%M:%S'),
                    'error': str(e)
                }
            )

    def _process_trigger(self, trigger: Dict[str, Any]) -> None:
        """Process individual trigger with deduplication"""
        trigger_id = trigger.get('id')
        trigger_name = trigger.get('name')
        payload = trigger.get('payload', {})

        if not trigger_id or not trigger_name:
            logger.error('Trigger missing id or name')
            return

        # Check for duplicate execution
        if self._is_trigger_duplicate(trigger_id, trigger_name):
            logger.warning(f'Skipping duplicate trigger: {trigger_name} ({trigger_id})')
            return

        logger.info(f'Executing trigger: {trigger_name} ({trigger_id})')

        handler = self.trigger_handlers.get(trigger_name)
        if not handler:
            logger.error(f'Unknown trigger type: {trigger_name}')
            self._register_trigger_execution(
                trigger_id,
                trigger_name,
                TriggerStatus.ERROR,
                payload=payload,
                error_message=f'Unknown trigger type: {trigger_name}'
            )
            return

        try:
            with self._trigger_execution_context(trigger_id, trigger_name, payload):
                result = handler(payload)
                
                webhook_payload = {
                    'status': result.status.value,
                    'datetime': timezone.now().strftime('%Y-%m-%d %H:%M:%S'),
                }
                
                if result.result:
                    webhook_payload['result'] = result.result
                if result.error_message:
                    webhook_payload['error'] = result.error_message
                
                self._send_webhook(trigger_name, webhook_payload)

        except Exception as e:
            logger.error(f'Trigger execution failed: {trigger_name} - {e}')

    def execute(self) -> None:
        """Main coordination loop"""
        logger.info('DAC Boot started')
        
        while self.running:
            try:
                self.auto_reboot()
                self.check_and_execute_triggers()
                self._initialize_settings()
            except Exception as e:
                logger.error(f'Main loop error: {e}')
            
            time.sleep(self.MAIN_LOOP_INTERVAL)

    def stop(self) -> None:
        """Gracefully stop the DAC boot process"""
        logger.info('Stopping DAC Boot...')
        self.running = False
        logger.info('DAC Boot stopped')


if __name__ == '__main__':
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    
    boot = DacBoot()
    
    try:
        boot.execute()
    except KeyboardInterrupt:
        logger.info('Received keyboard interrupt')
        boot.stop()
    except Exception as e:
        logger.error(f'Fatal error: {e}')
        boot.stop()
        raise