import pytz
from pymodbus.client import ModbusTcpClient
from pymodbus.exceptions import ModbusException
from model import Sensor, SensorMetrics
from django.db import transaction
from django.utils import timezone
from helps import bytes_to_value

def getDatetimeNow(tz='UTC'):
    try:
        now = timezone.now()
        local_tz = pytz.timezone(tz)
        date = now.astimezone(local_tz)
        return date.isoformat()
    except:
        return None

def getMetricsValue(sensor, default=None):
    try:
        status = SensorMetrics.objects.filter(sensor=sensor).first()
        if not status:
            return default
        value = status.getJson('meta.value')
        return value if value else default
    except Exception as e:
        print(e)
        return default

def setMetricsValue(sensor, field, value=None):
    try:
        if field is None:
            return
            
        status = SensorMetrics.objects.filter(sensor=sensor).first()
        with transaction.atomic():
            status.setJson(f'meta.{field}', value)
            status.save(update_fields=['meta'])
    except Exception as e:
        print(e)
    
def setMetricsValues(sensor, error=None, last_error_at=None, last_connected_at=None, value=None):
    try:
        status = SensorMetrics.objects.filter(sensor=sensor).first()
        with transaction.atomic():
            if not error is None:
                status.setJson('meta.error', error)
                status.setJson('meta.last_error_at',last_error_at if last_error_at else getDatetimeNow())
                status.setJson('meta.last_connected_at','')
                status.connected = False
            elif not last_connected_at is None:
                status.setJson('meta.last_connected_at',last_connected_at)
                status.setJson('meta.error', '')
                status.setJson('meta.last_error_at','')
                status.connected = True       
            
            if not value is None:
                status.setJson('meta.value', value)

            status.save()
    except Exception as e:
        print(f'[SENSOR STATUS] {e}')

def modbusReading(sensor:Sensor):
    status = SensorMetrics.objects.filter(sensor=sensor.code).first()
    try:
        if not sensor:
            setMetricsValues(sensor.code, 
                error=f'[MODBUS] Falha ao tentar estabelecer conexao, servidor não encontrado', 
            )
            return

        sensor_host = sensor.getJson('meta.modbus.host')
        sensor_port = sensor.getJson('meta.modbus.port', 502)
        sensor_timeout = sensor.getJson('meta.modbus.timeout', 3)

        client = ModbusTcpClient(
            host=sensor_host, 
            port=sensor_port, 
            timeout=sensor_timeout
            )
        client.connect()

        if not client.connected:
            setMetricsValues(sensor.code,  error=f'[MODBUS] Falha ao tentar estabelecer conexao com {sensor_host}:{sensor_port}')
            return
  
        modbusFunctionsMap = {
            'read_holding_registers': client.read_holding_registers,
            'read_input_registers': client.read_input_registers,
            'read_coils': client.read_coils,
            'read_discrete_inputs': client.read_discrete_inputs,
            'write_coil': client.write_coil,
            'write_coils': client.write_coils,
            'write_register': client.write_register,
            'write_registers': client.write_registers
        }
        modbusDataTypesMap = {
            "int16": client.DATATYPE.INT16,
            "uint16": client.DATATYPE.UINT16,
            "int32": client.DATATYPE.INT32,
            "uint32": client.DATATYPE.UINT32,
            "int64": client.DATATYPE.INT64,
            "uint64": client.DATATYPE.UINT64,
            "float32": client.DATATYPE.FLOAT32,
            "float64": client.DATATYPE.FLOAT64,
            "string": client.DATATYPE.STRING,
            "bits": client.DATATYPE.BITS,
        }
        modbusFunctions = sensor.getJson('meta.modbus.functions','read_holding_registers')

        if modbusFunctions not in modbusFunctionsMap:
            setMetricsValues(sensor.code, error=f'[MODBUS] função {modbusFunctions} nao encontrada', )
            return None

        response = modbusFunctionsMap[modbusFunctions](
            address=int(sensor.getJson('meta.modbus.address')),
            count=int(sensor.getJson('meta.modbus.count')),
            device_id=int(sensor.getJson('meta.modbus.slave')),
        )

        if response.isError():
            setMetricsValues(sensor.code, error=f'[MODBUS] Falha ao tentar ler dados')
            return None

        setMetricsValues(sensor.code, last_connected_at=getDatetimeNow())
        
        modbusFormat = sensor.getJson('meta.modbus.format', 'int16')
        if hasattr(response, 'registers'):
            if modbusFormat and modbusFormat != 'test':
                return bytes_to_value(data_bytes=response.registers, display_format=modbusFormat)
                # return client.convert_from_registers(registers=response.registers, data_type=modbusDataTypesMap[modbusFormat])
            return response.registers
        elif hasattr(response, 'bits'):
            return response.bits
        else:
            setMetricsValues(sensor.code, error='[MODBUS] Falha ao tentar formatar dados')
            return None

    except (ModbusException, Exception) as e:
        setMetricsValues(sensor.code, error=f'[MODBUS] {e}')
        return None
    finally:
        try:
            client.close()
        except:
            pass
    return None