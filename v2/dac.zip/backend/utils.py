import base64
import random
import string
import re
import netifaces

def encode_base64(data: str) -> str:
    """Codifica uma string para base64."""
    try:
        encoded_data = base64.b64encode(data.encode('utf-8')).decode('utf-8')
        return encoded_data
    except Exception as e:
        print(f"Erro ao codificar em base64: {e}")
        return None

def decode_base64(encoded_data: str) -> str:
    """Decodifica uma string de base64 para texto original."""
    try:
        decoded_data = base64.b64decode(encoded_data.encode('utf-8')).decode('utf-8')
        return decoded_data
    except Exception as e:
        print(f"Erro ao decodificar de base64: {e}")
        return None