import logging
import time
from server_request import RequestServer
from model import Sensor, Metrics, Reading, Device
from rest_framework import serializers
from django.db import transaction, connections, close_old_connections
from protocols import setMetricsValue, getDatetimeNow
from helps import get_ip_address, get_mac_address, collect_metrics
from math import ceil
from django.utils.timezone import localtime

logger = logging.getLogger(__name__)

class SensorMetricsSerializer(serializers.ModelSerializer):
    class Meta:
        model = Metrics
        fields = '__all__' 

class ReadingSerializer(serializers.ModelSerializer):
    class Meta:
        model = Reading
        fields = '__all__'

class SensorSerializer(serializers.ModelSerializer):
    metrics = serializers.SerializerMethodField()
    class Meta:
        model = Sensor
        fields = '__all__'
        extra_fields = ['metrics']
    
    def get_metrics(self, obj):
        try:
            metrics = Metrics.objects.filter(sensor=obj.code).first()
            if metrics:
                return SensorMetricsSerializer(metrics).data
            return None
        except Exception as e:
            logger.error(f'Error in get_metrics: {e}')
            return None


class DacSender:

    def __init__(self, max_workers: int = 50):
        self.http_client = RequestServer()
        self.settings = Device.objects.first()
        self.running = True
    
    def sync_readings(self):
        try:
            settings = Device.objects.first()
            if not settings:
                return
            
            send_readings = settings.getJson('meta.send', False)

            if not send_readings:
                return
            
            all_ids = list(Reading.objects.values_list('id', flat=True))
            count_readings = len(all_ids)

            if count_readings == 0:
                return

            block_size = 150
            num_blocks = ceil(count_readings / block_size)

            for block_num in range(num_blocks):
                start_idx = block_num * block_size
                end_idx = (block_num + 1) * block_size
                ids_chunk = all_ids[start_idx:end_idx]
                self.execute_block(ids_chunk)
                time.sleep(2)
   
        except Exception as e:
            logger.error(f'Error in sync_readings: {e}')

    def execute_block(self, reading_ids):
        try:
            close_old_connections()
            data_block = Reading.objects.filter(id__in=reading_ids)
            
            if not data_block.exists():
                return
            
            block_data_list = []
            valid_ids = []
            for reading in data_block:
                try:
                    payload = {
                        "company":self.settings.key,
                        "source":reading.sensor,
                        "protocol":"modbus",
                        "datetime":localtime(reading.created_at).strftime('%Y-%m-%d %H:%M:%S'),
                        "readings":reading.values
                    }
                    block_data_list.append(payload)
                    valid_ids.append(reading.id)
                except Exception as e:
                    logger.error(f'Error in execute_block: {e}, reading {reading.id}')
                    continue

            if block_data_list:
                response =  self.http_client.post('production/register', block_data_list)
                if response and response.status_code and response.status_code in [200, 201]:
                    Reading.objects.filter(id__in=valid_ids).delete()
            
        except Exception as e:
            logger.error(f'Error in execute_block: {e}')
        finally:
            close_old_connections()

    def sync_dac(self):
        try:
            self.settings = Device.objects.first()
            if not self.settings:
                Device.createNewSettings()
                self.settings = Device.objects.first()
            
            sync = self.settings.getJson('meta.sync', False)

            if not sync:
                return
            
            http_client = RequestServer()
            query = Sensor.objects.all()           
            serialized = SensorSerializer(query, many=True)

            serializer = {
                'sensors': serialized.data,
                'device': {
                    'mac': str(get_mac_address()),
                    'ip': str(get_ip_address()),
                    'metrics': collect_metrics()
                }
            }

            response = http_client.post('dac/update', serializer)

            if response and response.status_code and response.status_code in [200]:                
                try:
                    remote_list_update = response.json()
                                                            
                    if not isinstance(remote_list_update, (list, dict)):
                        return

                    with transaction.atomic():
                        
                        for item in remote_list_update.get('sensors', []):
                            try:
                                setMetricsValue(item, field='last_sync_at', value=getDatetimeNow())
                            except Exception as e:
                                logger.error(f'Error in sync: {e}, update last_sync_at for {item.get("sensor")}')

                except Exception as e:
                    logger.error(f'Error in sync: {e}, get list update')
            else:
                logger.error(f'Error in sync invalid response')
           
        except Exception as e:
            logger.error(f'Error in sync: {e}')
        
        
    def execute(self):
        """Main coordination loop"""
        logger.info('DAC started sender')
        try:
            while self.running:
                # self.sync_dac()
                self.sync_readings()
                time.sleep(25)
                
        except Exception as e:
            logger.error(f'Error in main loop: {e}')
        finally:
            self.stop()

    def stop(self):
        """Gracefully stop all readers and shutdown executor"""
        logger.info('Stopping DAC...')
        self.running = False    
        logger.info('DAC stopped')

    def ready(self):
        """Wait for interruption signal"""
        try:
            while True:
                time.sleep(1)
        except KeyboardInterrupt:
            logger.info('Received interrupt signal')
        finally:
            self.stop()


if __name__ == '__main__':
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    
    dac = DacSender()
    
    try:
        dac.execute()
        dac.ready()
    except KeyboardInterrupt:
        dac.stop()