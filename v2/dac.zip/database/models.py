from django.db import models
from django.core.exceptions import ValidationError
from django.utils import timezone
import netifaces
import pytz
import datetime

def get_mac_address():
    try:
        interfaces = netifaces.interfaces()
        for interface in interfaces:
            if interface == 'lo':
                continue
            iface = netifaces.ifaddresses(interface).get(netifaces.AF_LINK)
            if iface != None:
                for link in iface:
                    return link['addr']
    except Exception as e:
        print(e)
        return None

def generationCode():
    try:
        now = datetime.datetime.now()
        localTz = pytz.timezone(timezone.get_current_timezone_name())
        localNow = now.astimezone(localTz)

        timestamp_us = int(localNow.timestamp() * 1_000_000)

        # Garante exatamente 9 dígitos
        code = int(str(timestamp_us)[-9:])

        return code

    except Exception as e:
        print(e)
        return None

class BaseModel(models.Model):
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        abstract = True
    
    def setJson(self, keyPath:str, value, save: bool = False):
        try:
            if not keyPath:
                return
            keys = keyPath.split('.')
            fieldName = keys.pop(0)
            
            data = getattr(self, fieldName, None)
            
            if not isinstance(data, dict):
                data = {}
            
            current = data
            for key in keys[:-1]:
                if key not in current or not isinstance(current[key], dict):
                    current[key] = {}
                current = current[key]
            
            current[keys[-1]] = value
            
            setattr(self, fieldName, data)
            
            if save:
                self.save()
        except Exception as e:
            print(e)
            return 

    def getJson(self, keyPath, default=None):
        if not keyPath:
            return default
        
        keys = keyPath.split('.')
        firstKey = keys.pop(0)

        value = getattr(self, firstKey, None)
        for key in keys:
            if isinstance(value, dict) and key in value:
                value = value[key]
            else:
                return default

        return value if value is not None else default

class Device(BaseModel):
    host = models.TextField(null=True, blank=True)
    key = models.TextField(null=True, blank=True)
    meta = models.JSONField(null=True, blank=True)

    @classmethod
    def createNewSettings(cls):
        if cls.objects.exists():
            raise ValidationError('Device already exists')
        settings = cls(
            host = None,
            key = None,
            meta = {
                "reboot": {
                    "active": False,
                    "time": None,
                    "last": None
                },
                "send": False,
                "sync": False,
                "readings":False
            }
        )
        settings.save()
        return settings

    def clean(self):
        if not self.pk and Device.objects.exists():
            raise ValidationError('Only one instance of Device is allowed')

    def delete(self, *args, **kwargs):
        if Device.objects.count() == 1:
            raise ValidationError('Cannot delete the last instance of Device')
        super().delete(*args, **kwargs)


    class Meta:
        db_table = 'devices'
        

class Metrics(BaseModel):
    sensor = models.BigIntegerField(null=False, blank=False, unique=True)
    connected = models.BooleanField(default=False)
    meta = models.JSONField(null=True, blank=True)

    class Meta:
        db_table = 'metrics'
    
class Sensor(BaseModel):
    code = models.BigIntegerField(unique=True, null=True, blank=True)
    active = models.BooleanField(default=False)
    name = models.CharField(max_length=80, null=False, blank=False, unique=True)
    description = models.TextField(null=True, blank=True)
    kind = models.CharField(max_length=10, null=False, blank=False, default='modbus')
    meta = models.JSONField(null=True, blank=True)

    class Meta:
        db_table = 'sensors'
    
    def save(self, *args, **kwargs):
        if not self.code:
            self.code = generationCode()
        if not self.meta:
            self.meta = {}
       
        super().save(*args, **kwargs)

class Reading(BaseModel):
    sensor = models.BigIntegerField(null=False, blank=False)
    values =  models.JSONField(null=True, blank=True, default=dict)
    datetime = models.DateTimeField(null=True, blank=True)

    class Meta:
        db_table = 'readings'

class TriggerExecution(models.Model):
    """
    Tracks trigger executions to prevent duplicates and provide audit trail.
    Records are automatically cleaned up after 24 hours.
    """
    
    trigger_id = models.CharField(max_length=255, db_index=True,)    
    trigger_name = models.CharField(
        max_length=100,
        db_index=True,
    )
    
    status = models.CharField(
        max_length=20,
        choices=[
            ('pending', 'Pending'),
            ('executing', 'Executing'),
            ('success', 'Success'),
            ('error', 'Error'),
            ('duplicate', 'Duplicate'),
        ],
        default='pending',
        db_index=True
    )
    
    payload = models.JSONField(
        default=dict,
    )
    
    result = models.JSONField(
        null=True,
        blank=True,
    )
    
    error_message = models.TextField(
        null=True,
        blank=True,
    )
    
    executed_at = models.DateTimeField(
        default=timezone.now,
    )
    
    created_at = models.DateTimeField(
        auto_now_add=True,
    )
    
    class Meta:
        db_table = 'trigger_execution'
        ordering = ['-created_at']
        indexes = [
            models.Index(fields=['trigger_id', 'trigger_name']),
            models.Index(fields=['status', 'created_at']),
        ]
