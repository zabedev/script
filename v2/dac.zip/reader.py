import time
import logging
from typing import Dict
from django.utils import timezone
from django.db import transaction
from model import Sensor, Metrics, Reading, Device
from protocols import modbusReading, setMetricsValues, getMetricsValue, setMetricsValue
from helps import convertValue, validate_or_convert, get_datetime, get_accumulated_difference, get_start_of_period

logger = logging.getLogger(__name__)

PROTOCOLS_MAPPING = {
    'modbus': modbusReading
}

class SensorReader:
    """Handles logic for a single sensor. Maintains its own state of when it was last read.
    """
    
    def __init__(self, sensor: Sensor):
        self.sensor = sensor
        self.last_read_time = 0.0
    
    def update_sensor_config(self, sensor:Sensor):
        self.sensor = sensor
    
    def get_interval(self) -> int:
        try:
            interval = int(self.sensor.getJson(keyPath='meta.interval', default=10))
            return max(1, interval)
        except (ValueError, TypeError):
            logger.warning(f'Invalid interval for sensor {self.sensor.name}, using default')
            return 10
    
    def ensure_status_exists(self):
        """Ensure Metrics record exists"""
        try:
            metrics, created = Metrics.objects.get_or_create(sensor=self.sensor.code)
            if created:
                with transaction.atomic():
                    metrics.connected = False
                    metrics.save(update_fields=['connected'])
        except Exception as e:
            logger.error(f'Error creating status for {self.sensor.code}: {e}')
    
    def created_reading_value(self, sensor:Sensor, values):
        try:
            if not isinstance(sensor, Sensor):
                raise ValueError('sensor não encontrado')
            
            with transaction.atomic():
                Reading.objects.create(sensor=sensor.code, values=values, datetime=timezone.now())
            
        except Exception as e:
            logger.error(f'Error creating reading for {self.sensor.code}: {e}')
            return False

    def process_reading(self) -> bool:
        """Execute single reading cycle. Returns True if successful."""
        try:
            allow_reading = self.sensor.active
            setMetricsValue(sensor=self.sensor.code, field='allow_reading', value=allow_reading)
            
            if not allow_reading:
                logger.warning(f'Sensor {self.sensor.name} not is active')
                return False
            
            protocol = PROTOCOLS_MAPPING.get(self.sensor.kind)
            if not protocol:
                logger.warning(f'Protocol {self.sensor.kind} not supported')
                return False
            
            modbus_response = protocol(sensor=self.sensor)
            
            if modbus_response is None:
                return False

            production_response:dict = modbus_response.get('production')
            operation_response:dict = modbus_response.get('operation')
            
            production_value = None
            operation_value = None
            response = []

            if production_response and production_response.get('status') == 'formatted':
                setMetricsValue(sensor=self.sensor.code, field='production.value',value=production_response.get('value'))

            production_convert_error, production_value = convertValue(sensor=self.sensor, alias='production', value=production_response.get('value'))
            if production_convert_error:
                setMetricsValues(self.sensor.code, error=f'[CONVERT] Um erro ocorreu ao tentar converter o valor da produção  Error:{production_convert_error}, {get_datetime("datetime")} ')
                logger.error(f'[CONVERT] {production_convert_error}')
                return False
                        
            production_previous = getMetricsValue(sensor=self.sensor.code, field='production.previous',  default=0)
            setMetricsValue(sensor=self.sensor.code, field='production.previous',value=production_value)
            production_value = get_accumulated_difference(new_value=production_value, previous_value=production_previous, use_abs=True)
            setMetricsValue(sensor=self.sensor.code, field='production.processed',value=production_value)

            if operation_response and operation_response.get('status') == 'formatted':
                setMetricsValue(sensor=self.sensor.code, field='operation.value',value=operation_response.get('value'))
                operation_convert_error, operation_value = convertValue(sensor=self.sensor, alias='operation', value=operation_response.get('value'))
                if operation_convert_error:
                    setMetricsValues(self.sensor.code, error=f'[CONVERT] Um erro ocorreu ao tentar converter o valor da produção  Error:{operation_convert_error}, {get_datetime("datetime")} ')
                    logger.error(f'[CONVERT] {operation_convert_error}')
                    return False
                setMetricsValue(sensor=self.sensor.code, field='operation.processed',value=operation_value)

            response.append({'alias':'parcial','insert': True, 'value':production_value})
            response.append({'alias':'speed','insert': False, 'value':operation_value})

            createReading = self.sensor.getJson('meta.reading_create', False)
            if createReading:
                self.created_reading_value(sensor=self.sensor, values=response)
           
            return True

        except Exception as e:
            logger.error(f'Error processing sensor {self.sensor.code}: {e}')
            return False
    

    def tick(self) -> bool:
        """
        Called by the main loop. Checks if it's time to read.
        Returns True if read was executed.
        """
        now = time.time()
        interval = self.get_interval()
        
        # Se o tempo passado desde a última leitura for maior que o intervalo
        if (now - self.last_read_time) >= interval:
            self.ensure_status_exists()
            self.process_reading()
            self.last_read_time = time.time()
            return True
            
        return False


class DacReader:
    def __init__(self, max_workers: int = 50):
        self.readers: Dict[str, SensorReader] = {}
        self.running = False
    
    def sync_sensors(self):
        """Synchronize active objects with database"""
        try:
            # Busca todas fontes ativas
            db_sensors = Sensor.objects.filter(active=True)
            db_sensor_map = {s.code: s for s in db_sensors}
            
            # 1. Remove readers de fontes que não existem mais ou foram desativadas
            current_codes = list(self.readers.keys())
            for code in current_codes:
                if code not in db_sensor_map:
                    logger.info(f'Removing reader for sensor: {code}')
                    del self.readers[code]
            
            # 2. Adiciona novos readers ou atualiza configurações dos existentes
            for code, sensor_obj in db_sensor_map.items():
                if code not in self.readers:
                    logger.info(f'Adding new reader for sensor: {code}')
                    self.readers[code] = SensorReader(sensor_obj)
                else:
                    # Atualiza o objeto sensor dentro do reader para pegar configs novas (intervalo, etc)
                    self.readers[code].update_sensor_config(sensor_obj)
                    
        except Exception as e:
            logger.error(f'Error syncing sensors: {e}')

    
    def execute(self):
        self.running = True
        logger.info('DAC started (Single Threaded Mode)')

        try:
            while self.running:
                settings = Device.objects.first()
                if not settings:
                    Device.createNewSettings()
                    settings = Device.objects.first()
                
                reading_enabled = settings and settings.getJson('meta.reading', False)

                if not reading_enabled:
                    # Se leitura desabilitada, limpa readers e dorme um pouco
                    if self.readers:
                        self.readers.clear()
                        logger.info("Reading disabled globally.")
                    time.sleep(2)
                    continue

                # Sincroniza lista de fontes (pode fazer isso a cada iteração ou colocar um timer para não pesar)
                self.sync_sensors()

                if not self.readers:
                    time.sleep(1)
                    continue

                # ==========================================
                # CORE LOOP: Itera sobre todos os readers
                # ==========================================
                for code, reader in self.readers.items():
                    try:
                        # O método tick verifica internamente se já deu o tempo do intervalo
                        reader.tick()
                    except Exception as e:
                        logger.error(f"Unexpected error in reader {code}: {e}")

                # Pequeno sleep para evitar uso de 100% da CPU em loop vazio
                # 0.1s é suficiente para responsividade sem overhead
                time.sleep(0.1) 

        except KeyboardInterrupt:
            logger.info("Stopping via KeyboardInterrupt")
        except Exception as e:
            logger.error(f'Critical error in main loop: {e}')
        finally:
            self.stop()
    
    def stop(self):
        self.running = False
        logger.info('DAC stopped')
    
    def ready(self):
        """Wait for interruption signal"""
        try:
            while self.running:
                time.sleep(1)
        except KeyboardInterrupt:
            logger.info('Received interrupt signal')
        finally:
            self.stop()


if __name__ == '__main__':
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    
    dac = DacReader()
    
    try:
        dac.execute()
        dac.ready()
    except KeyboardInterrupt:
        dac.stop()