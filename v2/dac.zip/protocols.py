import pytz
from pymodbus.client import ModbusTcpClient
from pymodbus.exceptions import ModbusException
from model import Sensor, Metrics
from django.db import transaction
from django.utils import timezone
from helps import bytes_to_value
import logging

logger = logging.getLogger(__name__)

def getDatetimeNow(tz='UTC'):
    try:
        now = timezone.now()
        local_tz = pytz.timezone(tz)
        date = now.astimezone(local_tz)
        return date.isoformat()
    except:
        return None

def getMetricsValue(sensor, field, default=None):
    try:
        metrics = Metrics.objects.filter(sensor=sensor).first()
        if not metrics:
            return default
        value = metrics.getJson(f'meta.{field}')
        return value if value else default
    except Exception as e:
        print(e)
        return default

def setMetricsValue(sensor, field, value=None):
    try:
        if field is None:
            return
            
        metrics = Metrics.objects.filter(sensor=sensor).first()
        with transaction.atomic():
            metrics.setJson(f'meta.{field}', value)
            metrics.save(update_fields=['meta'])
    except Exception as e:
        print(e)
    
def setMetricsValues(sensor, error=None, last_error_at=None, last_connected_at=None):
    try:
        metrics = Metrics.objects.filter(sensor=sensor).first()
        if not metrics:
            metrics = Metrics(sensor=sensor)
            metrics.meta = {}
            metrics.save()
        
        with transaction.atomic():
            if not error is None:
                metrics.setJson('meta.error', error)
                metrics.setJson('meta.last_error_at',last_error_at if last_error_at else getDatetimeNow())
                metrics.setJson('meta.last_connected_at','')
                metrics.connected = False
            elif not last_connected_at is None:
                metrics.setJson('meta.last_connected_at',last_connected_at)
                metrics.setJson('meta.error', '')
                metrics.setJson('meta.last_error_at','')
                metrics.connected = True       
           
            metrics.save()
    except Exception as e:
        print(f'[SENSOR STATUS] {e}')

def modbusReading(sensor:Sensor):
    try:
        if not sensor:
            setMetricsValues(sensor.code, 
                error=f'[MODBUS] Falha ao tentar estabelecer conexao, servidor não encontrado', 
            )
            return []

        sensor_host = sensor.getJson('meta.host')
        sensor_port = sensor.getJson('meta.port', 502)
        sensor_timeout = 3

        client = ModbusTcpClient(
            host=sensor_host, 
            port=sensor_port, 
            timeout=sensor_timeout
            )
        client.connect()

        if not client.connected:
            setMetricsValues(sensor.code,  error=f'[MODBUS] Falha ao tentar estabelecer conexao com {sensor_host}:{sensor_port}')
            logger.info(f'[MODBUS] Falha ao tentar estabelecer conexao com {sensor_host}:{sensor_port}')
            return []
  
        modbusFunctionsMap = {
            'read_holding_registers': client.read_holding_registers,
            'read_input_registers': client.read_input_registers,
            'read_coils': client.read_coils,
            'read_discrete_inputs': client.read_discrete_inputs,
            'write_coil': client.write_coil,
            'write_coils': client.write_coils,
            'write_register': client.write_register,
            'write_registers': client.write_registers
        }
        # modbusDataTypesMap = {
        #     "int16": client.DATATYPE.INT16,
        #     "uint16": client.DATATYPE.UINT16,
        #     "int32": client.DATATYPE.INT32,
        #     "uint32": client.DATATYPE.UINT32,
        #     "int64": client.DATATYPE.INT64,
        #     "uint64": client.DATATYPE.UINT64,
        #     "float32": client.DATATYPE.FLOAT32,
        #     "float64": client.DATATYPE.FLOAT64,
        #     "string": client.DATATYPE.STRING,
        #     "bits": client.DATATYPE.BITS,
        # }
        modbusFunctions = sensor.getJson('meta.functions','read_holding_registers')

        if modbusFunctions not in modbusFunctionsMap:
            setMetricsValues(sensor.code, error=f'[MODBUS] função {modbusFunctions} nao encontrada', )
            logger.info(f'[MODBUS] função {modbusFunctions} nao encontrada')
            return []

        response_production = modbusFunctionsMap[modbusFunctions](
            address=int(sensor.getJson('meta.production.address')),
            count=int(sensor.getJson('meta.production.count')),
            device_id=int(sensor.getJson('meta.slave')),
        )

        response_operation = modbusFunctionsMap[modbusFunctions](
            address=int(sensor.getJson('meta.operation.address')),
            count=int(sensor.getJson('meta.operation.count')),
            device_id=int(sensor.getJson('meta.slave')),
        )

        if response_production.isError():
            setMetricsValues(sensor.code, error=f'[MODBUS] Falha ao tentar ler de produção')
            logger.info(f'[MODBUS] Falha ao tentar ler de produção')
            return []

        if response_operation.isError():
            setMetricsValues(sensor.code, error=f'[MODBUS] Falha ao tentar ler dados operação')
            logger.info(f'[MODBUS] Falha ao tentar ler dados operação')
            return []

        setMetricsValues(sensor.code, last_connected_at=getDatetimeNow())
        
        create_response = {}

        modbusFormatProduction = sensor.getJson('meta.production.format', 'int16')
        modbusFormatOperation = sensor.getJson('meta.operation.format', 'int16')

        if hasattr(response_production, 'registers'):
            if modbusFormatProduction and modbusFormatProduction != 'test':
                create_response[sensor.getJson('meta.production.alias')] = {
                    'status': 'formatted',
                    'value': bytes_to_value(
                        data_bytes=response_production.registers,
                        display_format=modbusFormatProduction
                    )
                }
            else:
                create_response[sensor.getJson('meta.production.alias')] = {
                    'status': 'registers',
                    'value': response_production.registers
                }
        else:
            setMetricsValues(sensor.code, error='[MODBUS] Falha ao tentar formatar da produção')
            create_response[sensor.getJson('meta.production.alias')] = {
                'status': 'error',
                'value': 0
            }

        if hasattr(response_operation, 'registers'):
            if modbusFormatOperation and modbusFormatOperation != 'test':
                create_response[sensor.getJson('meta.operation.alias')] = {
                    'status': 'formatted',
                    'value': bytes_to_value(
                        data_bytes=response_operation.registers,
                        display_format=modbusFormatOperation
                    )
                }
            else:
                create_response[sensor.getJson('meta.operation.alias')] = {
                    'status': 'registers',
                    'value': response_operation.registers
                }
        else:
            setMetricsValues(sensor.code, error='[MODBUS] Falha ao tentar formatar de operação')
            create_response[sensor.getJson('meta.operation.alias')] = {
                'status': 'error',
                'value': 0
            }

        return create_response

    except (ModbusException, Exception) as e:
        setMetricsValues(sensor.code, error=f'[MODBUS] {e}')
        logger.info(f'[MODBUS] {e}')
        return []
    finally:
        try:
            client.close()
        except:
            pass
