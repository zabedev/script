import{B as D,aH as z,aI as R,J as T,Y as d,a7 as f,aJ as _,am as j,x as P,aK as F,aL as V,Z as S,aM as C,aN as G,aO as W,W as N,aa as v,aP as k,aj as L,b as $,o as b,h as g,m as p,y,aQ as U,aR as Z,aw as x,ax as O,aS as s,aT as K,r as A,g as q,c as B,d as J,n as Q,Q as Y,aU as X,G as ee}from"./index-Doi0OnXo.js";import{C as te}from"./index-DMPzeDS5.js";import{a as oe}from"./index-Dp8Izm-E.js";var ne=({dt:t})=>`
.p-tooltip {
    position: absolute;
    display: none;
    max-width: ${t("tooltip.max.width")};
}

.p-tooltip-right,
.p-tooltip-left {
    padding: 0 ${t("tooltip.gutter")};
}

.p-tooltip-top,
.p-tooltip-bottom {
    padding: ${t("tooltip.gutter")} 0;
}

.p-tooltip-text {
    white-space: pre-line;
    word-break: break-word;
    background: ${t("tooltip.background")};
    color: ${t("tooltip.color")};
    padding: ${t("tooltip.padding")};
    box-shadow: ${t("tooltip.shadow")};
    border-radius: ${t("tooltip.border.radius")};
}

.p-tooltip-arrow {
    position: absolute;
    width: 0;
    height: 0;
    border-color: transparent;
    border-style: solid;
}

.p-tooltip-right .p-tooltip-arrow {
    margin-top: calc(-1 * ${t("tooltip.gutter")});
    border-width: ${t("tooltip.gutter")} ${t("tooltip.gutter")} ${t("tooltip.gutter")} 0;
    border-right-color: ${t("tooltip.background")};
}

.p-tooltip-left .p-tooltip-arrow {
    margin-top: calc(-1 * ${t("tooltip.gutter")});
    border-width: ${t("tooltip.gutter")} 0 ${t("tooltip.gutter")} ${t("tooltip.gutter")};
    border-left-color: ${t("tooltip.background")};
}

.p-tooltip-top .p-tooltip-arrow {
    margin-left: calc(-1 * ${t("tooltip.gutter")});
    border-width: ${t("tooltip.gutter")} ${t("tooltip.gutter")} 0 ${t("tooltip.gutter")};
    border-top-color: ${t("tooltip.background")};
    border-bottom-color: ${t("tooltip.background")};
}

.p-tooltip-bottom .p-tooltip-arrow {
    margin-left: calc(-1 * ${t("tooltip.gutter")});
    border-width: 0 ${t("tooltip.gutter")} ${t("tooltip.gutter")} ${t("tooltip.gutter")};
    border-top-color: ${t("tooltip.background")};
    border-bottom-color: ${t("tooltip.background")};
}
`,ie={root:"p-tooltip p-component",arrow:"p-tooltip-arrow",text:"p-tooltip-text"},re=D.extend({name:"tooltip-directive",style:ne,classes:ie}),ae=z.extend({style:re});function le(t,e){return ue(t)||de(t,e)||ce(t,e)||se()}function se(){throw new TypeError(`Invalid attempt to destructure non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`)}function ce(t,e){if(t){if(typeof t=="string")return H(t,e);var o={}.toString.call(t).slice(8,-1);return o==="Object"&&t.constructor&&(o=t.constructor.name),o==="Map"||o==="Set"?Array.from(t):o==="Arguments"||/^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(o)?H(t,e):void 0}}function H(t,e){(e==null||e>t.length)&&(e=t.length);for(var o=0,n=Array(e);o<e;o++)n[o]=t[o];return n}function de(t,e){var o=t==null?null:typeof Symbol<"u"&&t[Symbol.iterator]||t["@@iterator"];if(o!=null){var n,i,r,l,c=[],a=!0,u=!1;try{if(r=(o=o.call(t)).next,e!==0)for(;!(a=(n=r.call(o)).done)&&(c.push(n.value),c.length!==e);a=!0);}catch(m){u=!0,i=m}finally{try{if(!a&&o.return!=null&&(l=o.return(),Object(l)!==l))return}finally{if(u)throw i}}return c}}function ue(t){if(Array.isArray(t))return t}function I(t,e,o){return(e=pe(e))in t?Object.defineProperty(t,e,{value:o,enumerable:!0,configurable:!0,writable:!0}):t[e]=o,t}function pe(t){var e=he(t,"string");return h(e)=="symbol"?e:e+""}function he(t,e){if(h(t)!="object"||!t)return t;var o=t[Symbol.toPrimitive];if(o!==void 0){var n=o.call(t,e);if(h(n)!="object")return n;throw new TypeError("@@toPrimitive must return a primitive value.")}return(e==="string"?String:Number)(t)}function h(t){"@babel/helpers - typeof";return h=typeof Symbol=="function"&&typeof Symbol.iterator=="symbol"?function(e){return typeof e}:function(e){return e&&typeof Symbol=="function"&&e.constructor===Symbol&&e!==Symbol.prototype?"symbol":typeof e},h(t)}var ze=ae.extend("tooltip",{beforeMount:function(e,o){var n,i=this.getTarget(e);if(i.$_ptooltipModifiers=this.getModifiers(o),o.value){if(typeof o.value=="string")i.$_ptooltipValue=o.value,i.$_ptooltipDisabled=!1,i.$_ptooltipEscape=!0,i.$_ptooltipClass=null,i.$_ptooltipFitContent=!0,i.$_ptooltipIdAttr=k("pv_id")+"_tooltip",i.$_ptooltipShowDelay=0,i.$_ptooltipHideDelay=0,i.$_ptooltipAutoHide=!0;else if(h(o.value)==="object"&&o.value){if(L(o.value.value)||o.value.value.trim()==="")return;i.$_ptooltipValue=o.value.value,i.$_ptooltipDisabled=!!o.value.disabled===o.value.disabled?o.value.disabled:!1,i.$_ptooltipEscape=!!o.value.escape===o.value.escape?o.value.escape:!0,i.$_ptooltipClass=o.value.class||"",i.$_ptooltipFitContent=!!o.value.fitContent===o.value.fitContent?o.value.fitContent:!0,i.$_ptooltipIdAttr=o.value.id||k("pv_id")+"_tooltip",i.$_ptooltipShowDelay=o.value.showDelay||0,i.$_ptooltipHideDelay=o.value.hideDelay||0,i.$_ptooltipAutoHide=!!o.value.autoHide===o.value.autoHide?o.value.autoHide:!0}}else return;i.$_ptooltipZIndex=(n=o.instance.$primevue)===null||n===void 0||(n=n.config)===null||n===void 0||(n=n.zIndex)===null||n===void 0?void 0:n.tooltip,this.bindEvents(i,o),e.setAttribute("data-pd-tooltip",!0)},updated:function(e,o){var n=this.getTarget(e);if(n.$_ptooltipModifiers=this.getModifiers(o),this.unbindEvents(n),!!o.value){if(typeof o.value=="string")n.$_ptooltipValue=o.value,n.$_ptooltipDisabled=!1,n.$_ptooltipEscape=!0,n.$_ptooltipClass=null,n.$_ptooltipIdAttr=n.$_ptooltipIdAttr||k("pv_id")+"_tooltip",n.$_ptooltipShowDelay=0,n.$_ptooltipHideDelay=0,n.$_ptooltipAutoHide=!0,this.bindEvents(n,o);else if(h(o.value)==="object"&&o.value)if(L(o.value.value)||o.value.value.trim()===""){this.unbindEvents(n,o);return}else n.$_ptooltipValue=o.value.value,n.$_ptooltipDisabled=!!o.value.disabled===o.value.disabled?o.value.disabled:!1,n.$_ptooltipEscape=!!o.value.escape===o.value.escape?o.value.escape:!0,n.$_ptooltipClass=o.value.class||"",n.$_ptooltipFitContent=!!o.value.fitContent===o.value.fitContent?o.value.fitContent:!0,n.$_ptooltipIdAttr=o.value.id||n.$_ptooltipIdAttr||k("pv_id")+"_tooltip",n.$_ptooltipShowDelay=o.value.showDelay||0,n.$_ptooltipHideDelay=o.value.hideDelay||0,n.$_ptooltipAutoHide=!!o.value.autoHide===o.value.autoHide?o.value.autoHide:!0,this.bindEvents(n,o)}},unmounted:function(e,o){var n=this.getTarget(e);this.remove(n),this.unbindEvents(n,o),n.$_ptooltipScrollHandler&&(n.$_ptooltipScrollHandler.destroy(),n.$_ptooltipScrollHandler=null)},timer:void 0,methods:{bindEvents:function(e,o){var n=this,i=e.$_ptooltipModifiers;i.focus?(e.$_focusevent=function(r){return n.onFocus(r,o)},e.addEventListener("focus",e.$_focusevent),e.addEventListener("blur",this.onBlur.bind(this))):(e.$_mouseenterevent=function(r){return n.onMouseEnter(r,o)},e.addEventListener("mouseenter",e.$_mouseenterevent),e.addEventListener("mouseleave",this.onMouseLeave.bind(this)),e.addEventListener("click",this.onClick.bind(this))),e.addEventListener("keydown",this.onKeydown.bind(this))},unbindEvents:function(e){var o=e.$_ptooltipModifiers;o.focus?(e.removeEventListener("focus",e.$_focusevent),e.$_focusevent=null,e.removeEventListener("blur",this.onBlur.bind(this))):(e.removeEventListener("mouseenter",e.$_mouseenterevent),e.$_mouseenterevent=null,e.removeEventListener("mouseleave",this.onMouseLeave.bind(this)),e.removeEventListener("click",this.onClick.bind(this))),e.removeEventListener("keydown",this.onKeydown.bind(this))},bindScrollListener:function(e){var o=this;e.$_ptooltipScrollHandler||(e.$_ptooltipScrollHandler=new te(e,function(){o.hide(e)})),e.$_ptooltipScrollHandler.bindScrollListener()},unbindScrollListener:function(e){e.$_ptooltipScrollHandler&&e.$_ptooltipScrollHandler.unbindScrollListener()},onMouseEnter:function(e,o){var n=e.currentTarget,i=n.$_ptooltipShowDelay;this.show(n,o,i)},onMouseLeave:function(e){var o=e.currentTarget,n=o.$_ptooltipHideDelay,i=o.$_ptooltipAutoHide;if(i)this.hide(o,n);else{var r=v(e.target,"data-pc-name")==="tooltip"||v(e.target,"data-pc-section")==="arrow"||v(e.target,"data-pc-section")==="text"||v(e.relatedTarget,"data-pc-name")==="tooltip"||v(e.relatedTarget,"data-pc-section")==="arrow"||v(e.relatedTarget,"data-pc-section")==="text";!r&&this.hide(o,n)}},onFocus:function(e,o){var n=e.currentTarget,i=n.$_ptooltipShowDelay;this.show(n,o,i)},onBlur:function(e){var o=e.currentTarget,n=o.$_ptooltipHideDelay;this.hide(o,n)},onClick:function(e){var o=e.currentTarget,n=o.$_ptooltipHideDelay;this.hide(o,n)},onKeydown:function(e){var o=e.currentTarget,n=o.$_ptooltipHideDelay;e.code==="Escape"&&this.hide(e.currentTarget,n)},tooltipActions:function(e,o){if(!(e.$_ptooltipDisabled||!G(e))){var n=this.create(e,o);this.align(e),!this.isUnstyled()&&W(n,250);var i=this;window.addEventListener("resize",function r(){N()||i.hide(e),window.removeEventListener("resize",r)}),n.addEventListener("mouseleave",function r(){i.hide(e),n.removeEventListener("mouseleave",r),e.removeEventListener("mouseenter",e.$_mouseenterevent),setTimeout(function(){return e.addEventListener("mouseenter",e.$_mouseenterevent)},50)}),this.bindScrollListener(e),S.set("tooltip",n,e.$_ptooltipZIndex)}},show:function(e,o,n){var i=this;n!==void 0?this.timer=setTimeout(function(){return i.tooltipActions(e,o)},n):this.tooltipActions(e,o)},tooltipRemoval:function(e){this.remove(e),this.unbindScrollListener(e)},hide:function(e,o){var n=this;clearTimeout(this.timer),o!==void 0?setTimeout(function(){return n.tooltipRemoval(e)},o):this.tooltipRemoval(e)},getTooltipElement:function(e){return document.getElementById(e.$_ptooltipId)},getArrowElement:function(e){var o=this.getTooltipElement(e);return T(o,'[data-pc-section="arrow"]')},create:function(e){var o=e.$_ptooltipModifiers,n=C("div",{class:!this.isUnstyled()&&this.cx("arrow"),"p-bind":this.ptm("arrow",{context:o})}),i=C("div",{class:!this.isUnstyled()&&this.cx("text"),"p-bind":this.ptm("text",{context:o})});e.$_ptooltipEscape?(i.innerHTML="",i.appendChild(document.createTextNode(e.$_ptooltipValue))):i.innerHTML=e.$_ptooltipValue;var r=C("div",I(I({id:e.$_ptooltipIdAttr,role:"tooltip",style:{display:"inline-block",width:e.$_ptooltipFitContent?"fit-content":void 0,pointerEvents:!this.isUnstyled()&&e.$_ptooltipAutoHide&&"none"},class:[!this.isUnstyled()&&this.cx("root"),e.$_ptooltipClass]},this.$attrSelector,""),"p-bind",this.ptm("root",{context:o})),n,i);return document.body.appendChild(r),e.$_ptooltipId=r.id,this.$el=r,r},remove:function(e){if(e){var o=this.getTooltipElement(e);o&&o.parentElement&&(S.clear(o),document.body.removeChild(o)),e.$_ptooltipId=null}},align:function(e){var o=e.$_ptooltipModifiers;o.top?(this.alignTop(e),this.isOutOfBounds(e)&&(this.alignBottom(e),this.isOutOfBounds(e)&&this.alignTop(e))):o.left?(this.alignLeft(e),this.isOutOfBounds(e)&&(this.alignRight(e),this.isOutOfBounds(e)&&(this.alignTop(e),this.isOutOfBounds(e)&&(this.alignBottom(e),this.isOutOfBounds(e)&&this.alignLeft(e))))):o.bottom?(this.alignBottom(e),this.isOutOfBounds(e)&&(this.alignTop(e),this.isOutOfBounds(e)&&this.alignBottom(e))):(this.alignRight(e),this.isOutOfBounds(e)&&(this.alignLeft(e),this.isOutOfBounds(e)&&(this.alignTop(e),this.isOutOfBounds(e)&&(this.alignBottom(e),this.isOutOfBounds(e)&&this.alignRight(e)))))},getHostOffset:function(e){var o=e.getBoundingClientRect(),n=o.left+F(),i=o.top+V();return{left:n,top:i}},alignRight:function(e){this.preAlign(e,"right");var o=this.getTooltipElement(e),n=this.getArrowElement(e),i=this.getHostOffset(e),r=i.left+d(e),l=i.top+(f(e)-f(o))/2;o.style.left=r+"px",o.style.top=l+"px",n.style.top="50%",n.style.right=null,n.style.bottom=null,n.style.left="0"},alignLeft:function(e){this.preAlign(e,"left");var o=this.getTooltipElement(e),n=this.getArrowElement(e),i=this.getHostOffset(e),r=i.left-d(o),l=i.top+(f(e)-f(o))/2;o.style.left=r+"px",o.style.top=l+"px",n.style.top="50%",n.style.right="0",n.style.bottom=null,n.style.left=null},alignTop:function(e){this.preAlign(e,"top");var o=this.getTooltipElement(e),n=this.getArrowElement(e),i=d(o),r=d(e),l=_(),c=l.width,a=this.getHostOffset(e),u=a.left+(d(e)-d(o))/2,m=a.top-f(o);a.left<i/2&&(u=a.left),a.left+i>c&&(u=Math.floor(a.left+r-i)),o.style.left=u+"px",o.style.top=m+"px";var w=a.left-this.getHostOffset(o).left+r/2;n.style.top=null,n.style.right=null,n.style.bottom="0",n.style.left=w+"px"},alignBottom:function(e){this.preAlign(e,"bottom");var o=this.getTooltipElement(e),n=this.getArrowElement(e),i=d(o),r=d(e),l=_(),c=l.width,a=this.getHostOffset(e),u=a.left+(d(e)-d(o))/2,m=a.top+f(e);a.left<i/2&&(u=a.left),a.left+i>c&&(u=Math.floor(a.left+r-i)),o.style.left=u+"px",o.style.top=m+"px";var w=a.left-this.getHostOffset(o).left+r/2;n.style.top="0",n.style.right=null,n.style.bottom=null,n.style.left=w+"px"},preAlign:function(e,o){var n=this.getTooltipElement(e);n.style.left="-999px",n.style.top="-999px",j(n,"p-tooltip-".concat(n.$_ptooltipPosition)),!this.isUnstyled()&&P(n,"p-tooltip-".concat(o)),n.$_ptooltipPosition=o,n.setAttribute("data-p-position",o)},isOutOfBounds:function(e){var o=this.getTooltipElement(e),n=o.getBoundingClientRect(),i=n.top,r=n.left,l=d(o),c=f(o),a=_();return r+l>a.width||r<0||i<0||i+c>a.height},getTarget:function(e){var o;return R(e,"p-inputwrapper")&&(o=T(e,"input"))!==null&&o!==void 0?o:e},getModifiers:function(e){return e.modifiers&&Object.keys(e.modifiers).length?e.modifiers:e.arg&&h(e.arg)==="object"?Object.entries(e.arg).reduce(function(o,n){var i=le(n,2),r=i[0],l=i[1];return(r==="event"||r==="position")&&(o[l]=!0),o},{}):{}}}}),fe={name:"ChevronDownIcon",extends:y};function be(t,e,o,n,i,r){return b(),$("svg",p({width:"14",height:"14",viewBox:"0 0 14 14",fill:"none",xmlns:"http://www.w3.org/2000/svg"},t.pti()),e[0]||(e[0]=[g("path",{d:"M7.01744 10.398C6.91269 10.3985 6.8089 10.378 6.71215 10.3379C6.61541 10.2977 6.52766 10.2386 6.45405 10.1641L1.13907 4.84913C1.03306 4.69404 0.985221 4.5065 1.00399 4.31958C1.02276 4.13266 1.10693 3.95838 1.24166 3.82747C1.37639 3.69655 1.55301 3.61742 1.74039 3.60402C1.92777 3.59062 2.11386 3.64382 2.26584 3.75424L7.01744 8.47394L11.769 3.75424C11.9189 3.65709 12.097 3.61306 12.2748 3.62921C12.4527 3.64535 12.6199 3.72073 12.7498 3.84328C12.8797 3.96582 12.9647 4.12842 12.9912 4.30502C13.0177 4.48162 12.9841 4.662 12.8958 4.81724L7.58083 10.1322C7.50996 10.2125 7.42344 10.2775 7.32656 10.3232C7.22968 10.3689 7.12449 10.3944 7.01744 10.398Z",fill:"currentColor"},null,-1)]),16)}fe.render=be;var ve={name:"ChevronLeftIcon",extends:y};function ge(t,e,o,n,i,r){return b(),$("svg",p({width:"14",height:"14",viewBox:"0 0 14 14",fill:"none",xmlns:"http://www.w3.org/2000/svg"},t.pti()),e[0]||(e[0]=[g("path",{d:"M9.61296 13C9.50997 13.0005 9.40792 12.9804 9.3128 12.9409C9.21767 12.9014 9.13139 12.8433 9.05902 12.7701L3.83313 7.54416C3.68634 7.39718 3.60388 7.19795 3.60388 6.99022C3.60388 6.78249 3.68634 6.58325 3.83313 6.43628L9.05902 1.21039C9.20762 1.07192 9.40416 0.996539 9.60724 1.00012C9.81032 1.00371 10.0041 1.08597 10.1477 1.22959C10.2913 1.37322 10.3736 1.56698 10.3772 1.77005C10.3808 1.97313 10.3054 2.16968 10.1669 2.31827L5.49496 6.99022L10.1669 11.6622C10.3137 11.8091 10.3962 12.0084 10.3962 12.2161C10.3962 12.4238 10.3137 12.6231 10.1669 12.7701C10.0945 12.8433 10.0083 12.9014 9.91313 12.9409C9.81801 12.9804 9.71596 13.0005 9.61296 13Z",fill:"currentColor"},null,-1)]),16)}ve.render=ge;var me={name:"ChevronRightIcon",extends:y};function $e(t,e,o,n,i,r){return b(),$("svg",p({width:"14",height:"14",viewBox:"0 0 14 14",fill:"none",xmlns:"http://www.w3.org/2000/svg"},t.pti()),e[0]||(e[0]=[g("path",{d:"M4.38708 13C4.28408 13.0005 4.18203 12.9804 4.08691 12.9409C3.99178 12.9014 3.9055 12.8433 3.83313 12.7701C3.68634 12.6231 3.60388 12.4238 3.60388 12.2161C3.60388 12.0084 3.68634 11.8091 3.83313 11.6622L8.50507 6.99022L3.83313 2.31827C3.69467 2.16968 3.61928 1.97313 3.62287 1.77005C3.62645 1.56698 3.70872 1.37322 3.85234 1.22959C3.99596 1.08597 4.18972 1.00371 4.3928 1.00012C4.59588 0.996539 4.79242 1.07192 4.94102 1.21039L10.1669 6.43628C10.3137 6.58325 10.3962 6.78249 10.3962 6.99022C10.3962 7.19795 10.3137 7.39718 10.1669 7.54416L4.94102 12.7701C4.86865 12.8433 4.78237 12.9014 4.68724 12.9409C4.59212 12.9804 4.49007 13.0005 4.38708 13Z",fill:"currentColor"},null,-1)]),16)}me.render=$e;const Re=U("gateway",()=>{const t=Z({servers:[],sensors:[],settings:{loading:x(!1),error:x(null),success:x(null),message:x(null)}}),n={sensor:{async index(){return await s.get("sensors/")},async show({id:i}){return await s.get(`sensors/${i}/`)},async store({data:i}){return await s.post("sensors/",i)},async update({id:i,data:r}){return await s.put(`sensors/${i}/`,r)},async delete({id:i}){return await s.delete(`sensors/${i}/`)},async readings({sensor:i}){return await s.get(`sensors/${i}/readings/`)},async deleteReading({id:i}){return await s.delete(`readings/${i}/`)},async deleteAllReadings({id:i}){return await s.delete(`sensors/${i}/readings/delete-all/`)},async updateSensorCode({id:i,code:r}){return await s.put(`sensors/${i}/update-code/`,{code:r})}},settings:{async index(){return await s.get("devices/")},async update({data:i}){return await s.put("devices/update/",i)},async testServer({url:i}){return await K.get({url:i})},async reboot(){return await s.post("devices/reboot/")},async restartService(){return await s.post("devices/restart/services/")}}};return{sensors:O(()=>t.sensors),settings:O(()=>t.settings),api:n}});var M={name:"MinusIcon",extends:y};function ke(t,e,o,n,i,r){return b(),$("svg",p({width:"14",height:"14",viewBox:"0 0 14 14",fill:"none",xmlns:"http://www.w3.org/2000/svg"},t.pti()),e[0]||(e[0]=[g("path",{d:"M13.2222 7.77778H0.777778C0.571498 7.77778 0.373667 7.69584 0.227806 7.54998C0.0819442 7.40412 0 7.20629 0 7.00001C0 6.79373 0.0819442 6.5959 0.227806 6.45003C0.373667 6.30417 0.571498 6.22223 0.777778 6.22223H13.2222C13.4285 6.22223 13.6263 6.30417 13.7722 6.45003C13.9181 6.5959 14 6.79373 14 7.00001C14 7.20629 13.9181 7.40412 13.7722 7.54998C13.6263 7.69584 13.4285 7.77778 13.2222 7.77778Z",fill:"currentColor"},null,-1)]),16)}M.render=ke;var xe=({dt:t})=>`
.p-checkbox {
    position: relative;
    display: inline-flex;
    user-select: none;
    vertical-align: bottom;
    width: ${t("checkbox.width")};
    height: ${t("checkbox.height")};
}

.p-checkbox-input {
    cursor: pointer;
    appearance: none;
    position: absolute;
    inset-block-start: 0;
    inset-inline-start: 0;
    width: 100%;
    height: 100%;
    padding: 0;
    margin: 0;
    opacity: 0;
    z-index: 1;
    outline: 0 none;
    border: 1px solid transparent;
    border-radius: ${t("checkbox.border.radius")};
}

.p-checkbox-box {
    display: flex;
    justify-content: center;
    align-items: center;
    border-radius: ${t("checkbox.border.radius")};
    border: 1px solid ${t("checkbox.border.color")};
    background: ${t("checkbox.background")};
    width: ${t("checkbox.width")};
    height: ${t("checkbox.height")};
    transition: background ${t("checkbox.transition.duration")}, color ${t("checkbox.transition.duration")}, border-color ${t("checkbox.transition.duration")}, box-shadow ${t("checkbox.transition.duration")}, outline-color ${t("checkbox.transition.duration")};
    outline-color: transparent;
    box-shadow: ${t("checkbox.shadow")};
}

.p-checkbox-icon {
    transition-duration: ${t("checkbox.transition.duration")};
    color: ${t("checkbox.icon.color")};
    font-size: ${t("checkbox.icon.size")};
    width: ${t("checkbox.icon.size")};
    height: ${t("checkbox.icon.size")};
}

.p-checkbox:not(.p-disabled):has(.p-checkbox-input:hover) .p-checkbox-box {
    border-color: ${t("checkbox.hover.border.color")};
}

.p-checkbox-checked .p-checkbox-box {
    border-color: ${t("checkbox.checked.border.color")};
    background: ${t("checkbox.checked.background")};
}

.p-checkbox-checked .p-checkbox-icon {
    color: ${t("checkbox.icon.checked.color")};
}

.p-checkbox-checked:not(.p-disabled):has(.p-checkbox-input:hover) .p-checkbox-box {
    background: ${t("checkbox.checked.hover.background")};
    border-color: ${t("checkbox.checked.hover.border.color")};
}

.p-checkbox-checked:not(.p-disabled):has(.p-checkbox-input:hover) .p-checkbox-icon {
    color: ${t("checkbox.icon.checked.hover.color")};
}

.p-checkbox:not(.p-disabled):has(.p-checkbox-input:focus-visible) .p-checkbox-box {
    border-color: ${t("checkbox.focus.border.color")};
    box-shadow: ${t("checkbox.focus.ring.shadow")};
    outline: ${t("checkbox.focus.ring.width")} ${t("checkbox.focus.ring.style")} ${t("checkbox.focus.ring.color")};
    outline-offset: ${t("checkbox.focus.ring.offset")};
}

.p-checkbox-checked:not(.p-disabled):has(.p-checkbox-input:focus-visible) .p-checkbox-box {
    border-color: ${t("checkbox.checked.focus.border.color")};
}

.p-checkbox.p-invalid > .p-checkbox-box {
    border-color: ${t("checkbox.invalid.border.color")};
}

.p-checkbox.p-variant-filled .p-checkbox-box {
    background: ${t("checkbox.filled.background")};
}

.p-checkbox-checked.p-variant-filled .p-checkbox-box {
    background: ${t("checkbox.checked.background")};
}

.p-checkbox-checked.p-variant-filled:not(.p-disabled):has(.p-checkbox-input:hover) .p-checkbox-box {
    background: ${t("checkbox.checked.hover.background")};
}

.p-checkbox.p-disabled {
    opacity: 1;
}

.p-checkbox.p-disabled .p-checkbox-box {
    background: ${t("checkbox.disabled.background")};
    border-color: ${t("checkbox.checked.disabled.border.color")};
}

.p-checkbox.p-disabled .p-checkbox-box .p-checkbox-icon {
    color: ${t("checkbox.icon.disabled.color")};
}

.p-checkbox-sm,
.p-checkbox-sm .p-checkbox-box {
    width: ${t("checkbox.sm.width")};
    height: ${t("checkbox.sm.height")};
}

.p-checkbox-sm .p-checkbox-icon {
    font-size: ${t("checkbox.icon.sm.size")};
    width: ${t("checkbox.icon.sm.size")};
    height: ${t("checkbox.icon.sm.size")};
}

.p-checkbox-lg,
.p-checkbox-lg .p-checkbox-box {
    width: ${t("checkbox.lg.width")};
    height: ${t("checkbox.lg.height")};
}

.p-checkbox-lg .p-checkbox-icon {
    font-size: ${t("checkbox.icon.lg.size")};
    width: ${t("checkbox.icon.lg.size")};
    height: ${t("checkbox.icon.lg.size")};
}
`,ye={root:function(e){var o=e.instance,n=e.props;return["p-checkbox p-component",{"p-checkbox-checked":o.checked,"p-disabled":n.disabled,"p-invalid":o.$pcCheckboxGroup?o.$pcCheckboxGroup.$invalid:o.$invalid,"p-variant-filled":o.$variant==="filled","p-checkbox-sm p-inputfield-sm":n.size==="small","p-checkbox-lg p-inputfield-lg":n.size==="large"}]},box:"p-checkbox-box",input:"p-checkbox-input",icon:"p-checkbox-icon"},we=D.extend({name:"checkbox",style:xe,classes:ye}),_e={name:"BaseCheckbox",extends:oe,props:{value:null,binary:Boolean,indeterminate:{type:Boolean,default:!1},trueValue:{type:null,default:!0},falseValue:{type:null,default:!1},readonly:{type:Boolean,default:!1},required:{type:Boolean,default:!1},tabindex:{type:Number,default:null},inputId:{type:String,default:null},inputClass:{type:[String,Object],default:null},inputStyle:{type:Object,default:null},ariaLabelledby:{type:String,default:null},ariaLabel:{type:String,default:null}},style:we,provide:function(){return{$pcCheckbox:this,$parentInstance:this}}};function Ce(t){return Le(t)||Se(t)||Te(t)||Ee()}function Ee(){throw new TypeError(`Invalid attempt to spread non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`)}function Te(t,e){if(t){if(typeof t=="string")return E(t,e);var o={}.toString.call(t).slice(8,-1);return o==="Object"&&t.constructor&&(o=t.constructor.name),o==="Map"||o==="Set"?Array.from(t):o==="Arguments"||/^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(o)?E(t,e):void 0}}function Se(t){if(typeof Symbol<"u"&&t[Symbol.iterator]!=null||t["@@iterator"]!=null)return Array.from(t)}function Le(t){if(Array.isArray(t))return E(t)}function E(t,e){(e==null||e>t.length)&&(e=t.length);for(var o=0,n=Array(e);o<e;o++)n[o]=t[o];return n}var Oe={name:"Checkbox",extends:_e,inheritAttrs:!1,emits:["change","focus","blur","update:indeterminate"],inject:{$pcCheckboxGroup:{default:void 0}},data:function(){return{d_indeterminate:this.indeterminate}},watch:{indeterminate:function(e){this.d_indeterminate=e}},methods:{getPTOptions:function(e){var o=e==="root"?this.ptmi:this.ptm;return o(e,{context:{checked:this.checked,indeterminate:this.d_indeterminate,disabled:this.disabled}})},onChange:function(e){var o=this;if(!this.disabled&&!this.readonly){var n=this.$pcCheckboxGroup?this.$pcCheckboxGroup.d_value:this.d_value,i;this.binary?i=this.d_indeterminate?this.trueValue:this.checked?this.falseValue:this.trueValue:this.checked||this.d_indeterminate?i=n.filter(function(r){return!ee(r,o.value)}):i=n?[].concat(Ce(n),[this.value]):[this.value],this.d_indeterminate&&(this.d_indeterminate=!1,this.$emit("update:indeterminate",this.d_indeterminate)),this.$pcCheckboxGroup?this.$pcCheckboxGroup.writeValue(i,e):this.writeValue(i,e),this.$emit("change",e)}},onFocus:function(e){this.$emit("focus",e)},onBlur:function(e){var o,n;this.$emit("blur",e),(o=(n=this.formField).onBlur)===null||o===void 0||o.call(n,e)}},computed:{groupName:function(){return this.$pcCheckboxGroup?this.$pcCheckboxGroup.groupName:this.$formName},checked:function(){var e=this.$pcCheckboxGroup?this.$pcCheckboxGroup.d_value:this.d_value;return this.d_indeterminate?!1:this.binary?e===this.trueValue:X(this.value,e)}},components:{CheckIcon:Y,MinusIcon:M}},Ae=["data-p-checked","data-p-indeterminate","data-p-disabled"],Be=["id","value","name","checked","tabindex","disabled","readonly","required","aria-labelledby","aria-label","aria-invalid","aria-checked"];function He(t,e,o,n,i,r){var l=A("CheckIcon"),c=A("MinusIcon");return b(),$("div",p({class:t.cx("root")},r.getPTOptions("root"),{"data-p-checked":r.checked,"data-p-indeterminate":i.d_indeterminate||void 0,"data-p-disabled":t.disabled}),[g("input",p({id:t.inputId,type:"checkbox",class:[t.cx("input"),t.inputClass],style:t.inputStyle,value:t.value,name:r.groupName,checked:r.checked,tabindex:t.tabindex,disabled:t.disabled,readonly:t.readonly,required:t.required,"aria-labelledby":t.ariaLabelledby,"aria-label":t.ariaLabel,"aria-invalid":t.invalid||void 0,"aria-checked":i.d_indeterminate?"mixed":void 0,onFocus:e[0]||(e[0]=function(){return r.onFocus&&r.onFocus.apply(r,arguments)}),onBlur:e[1]||(e[1]=function(){return r.onBlur&&r.onBlur.apply(r,arguments)}),onChange:e[2]||(e[2]=function(){return r.onChange&&r.onChange.apply(r,arguments)})},r.getPTOptions("input")),null,16,Be),g("div",p({class:t.cx("box")},r.getPTOptions("box")),[q(t.$slots,"icon",{checked:r.checked,indeterminate:i.d_indeterminate,class:Q(t.cx("icon"))},function(){return[r.checked?(b(),B(l,p({key:0,class:t.cx("icon")},r.getPTOptions("icon")),null,16,["class"])):i.d_indeterminate?(b(),B(c,p({key:1,class:t.cx("icon")},r.getPTOptions("icon")),null,16,["class"])):J("",!0)]})],16)],16,Ae)}Oe.render=He;export{ze as T,me as a,ve as b,Oe as c,fe as s,Re as u};
