from model import Source, SourceStatus, Reading, Settings
from django.utils import timezone # type: ignore
import time
import threading
from concurrent.futures import ThreadPoolExecutor
from django.db import transaction # pyright: ignore[reportMissingModuleSource]
from protocols import modbusReading, setSourceStatus, getSourceStatusValue, setValueForSourceStatus
from helps import convertValue, validate_or_convert, get_datetime, get_accumulated_difference, get_start_of_period
from typing import Dict, Optional
import logging
from decimal import Decimal

logger = logging.getLogger(__name__)

PROTOCOLS_MAPPING = {
    'modbus': modbusReading
}

class SourceReader:
    """Handles individual source reading in isolated thread"""
    
    def __init__(self, source: Source, stop_event: threading.Event):
        self.source = source
        self.stop_event = stop_event
        self.last_read = None
        
    def get_interval(self) -> int:
        try:
            interval = int(self.source.getJson(keyPath='meta.reading.interval', default=5))
            return max(1, interval)  # Minimum 1 second
        except (ValueError, TypeError):
            logger.warning(f'Invalid interval for source {self.source.name}, using default')
            return 5
    
    def ensure_status_exists(self):
        """Ensure SourceStatus record exists"""
        try:
            status, created = SourceStatus.objects.get_or_create(source=self.source.code)
            if created:
                with transaction.atomic():
                    status.is_connected = False
                    status.save(update_fields=['is_connected'])
        except Exception as e:
            logger.error(f'Error creating status for {self.source.code}: {e}')
    
    def created_reading_value(self, source:Source, value: int | float | dict):
        try:
            if not isinstance(source, Source):
                raise ValueError('Fonte não encontrada')
            if isinstance(value, (int, float)):
                groupingAllow = source.getJson('meta.reading.grouping', None)
                creationType = source.getJson('meta.reading.type', 'realtime')
                now = timezone.now()
                match creationType:
                    case 'historical':
                        if not groupingAllow is None:
                            grouping_filter_time = get_start_of_period(groupingAllow, now=timezone.now() )
                            with transaction.atomic():
                                reading, created = Reading.objects.select_for_update().get_or_create(
                                    source=source.code,
                                    grouping=groupingAllow,
                                    creation_type=creationType,
                                    datetime=grouping_filter_time,
                                    defaults={"value": 0, "is_open":True,}                                    
                                )
                                if created:
                                    Reading.objects.filter(
                                        source=source.code,
                                        creation_type=creationType,
                                        is_open=True
                                    ).update(is_open=False, closed_at=now)
                                reading.value += value
                                reading.opened_at = timezone.now()
                                reading.save()
                                return True
                        else:
                            with transaction.atomic():
                                Reading.objects.create(
                                    source=source.code,
                                    creation_type=creationType,
                                    value=value,
                                    is_open=False,
                                    grouping=None,
                                    datetime=timezone.now(),
                                    opened_at=timezone.now(),
                                    closed_at=timezone.now()
                                )
                                return True
                    
                    case 'realtime':
                        with transaction.atomic():
                            reading, created = Reading.objects.get_or_create(
                                source=source.code,
                                creation_type=creationType,
                                grouping=None,
                                defaults={"value":0, "is_open":False, "opened_at":timezone.now(), }
                            )
                            reading.datetime = timezone.now()
                            reading.closed_at = timezone.now()
                            reading.value = value
                            reading.save()
                            return True
                    case _:
                        return False                    

            elif isinstance(value, dict):
                pass
            else:
                raise ValueError('Valor inválido')
            
        except Exception as e:
            logger.error(f'Error creating reading for {self.source.code}: {e}')
            return False

    def process_reading(self) -> bool:
        """Execute single reading cycle. Returns True if successful."""
        try:
            allow_reading = self.source.is_active
            setValueForSourceStatus(source=self.source.code, field='allow_reading', value=allow_reading)
            
            if not allow_reading:
                logger.warning(f'Source {self.source.name} not is active')
                return False
            
            protocol = PROTOCOLS_MAPPING.get(self.source.source_type)
            if not protocol:
                logger.warning(f'Protocol {self.source.source_type} not supported')
                return False
            
            response = protocol(source=self.source)
            
            if response is None:
                return False
            
            previous = getSourceStatusValue(source=self.source.code, default=0)
            setValueForSourceStatus(source=self.source.code, field='reading',value=response)

            convert_error, response = convertValue(source=self.source, value=response)
            if convert_error:
                setSourceStatus(self.source.code, error=f'[CONVERT] Um erro ocorreu ao tentar converter o valor {response} Error:{convert_error}, {get_datetime("datetime")} ')
                logger.error(f'[CONVERT] {convert_error}')
                return False

            evaluators = self.source.getJson(f'meta.reading.evaluators', [])
            if len(evaluators) > 0:
                validate_error, response = validate_or_convert(evaluators, response)
                if validate_error:
                    setSourceStatus(self.source.code, error=f'[VALIDATE] Um erro ocorreu ao tentar validar o valor {response} Error:{validate_error}, {get_datetime("datetime")} ')
                    logger.error(f'[VALIDATE] {validate_error}')
                    return False

            
            setValueForSourceStatus(source=self.source.code, field='value', value=response)
            setValueForSourceStatus(source=self.source.code, field='previous', value=previous)

            calculateDifference = self.source.getJson('meta.reading.calculate.difference', False)
            calculateDifferenceAbs = self.source.getJson('meta.reading.calculate.use_abs', False)
            
            if calculateDifference:
                response = get_accumulated_difference(new_value=response, previous_value=previous, use_abs=calculateDifferenceAbs)

            if response is None:
                return False
                            
            evaluators_accumulated = self.source.getJson('meta.reading.calculate.evaluators', [])
            if len(evaluators_accumulated) > 0:
                validate_error, response = validate_or_convert(evaluators_accumulated, response)
                if validate_error:
                    setSourceStatus(self.source.code, error=f'[VALIDATE] Um erro ocorreu ao tentar validar o valor {response} Error:{validate_error}, {get_datetime("datetime")} ')
                    logger.error(f'[VALIDATE] {validate_error}')
                    return False
                
            allowCreateReading = self.source.getJson('meta.reading.allow_create', False)
            if allowCreateReading:
                self.created_reading_value(source=self.source, value=response)
            

            logger.info(f'Source {self.source.code}: {response} at {timezone.now()}')
            
            return True
            
        except Exception as e:
            logger.error(f'Error processing source {self.source.code}: {e}')
            return False
    
    def run(self):
        """Main reading loop for this source"""
        self.ensure_status_exists()
        
        logger.info(f'Started reader for source {self.source.code}')
        
        while not self.stop_event.is_set():
            try:
                # Refresh source config from DB
                self.source.refresh_from_db()
                
                # Check if source was deactivated
                if not self.source.is_active:
                    logger.info(f'Source {self.source.code} deactivated, stopping reader')
                    break
                
                # Execute reading
                self.process_reading()
                
                # Sleep with interval check to allow quick shutdown
                interval = self.get_interval()
                for _ in range(interval):
                    if self.stop_event.is_set():
                        break
                    time.sleep(1)
                    
            except Exception as e:
                logger.error(f'Error in reader loop for {self.source.code}: {e}')
                time.sleep(5)  # Backoff on error
        
        logger.info(f'Stopped reader for source {self.source.code}')


class DacReader:
    def __init__(self, max_workers: int = 50):
        self.sources: list[Source] = []
        self.active_readers: Dict[str, tuple[SourceReader, threading.Event]] = {}
        self.executor = ThreadPoolExecutor(max_workers=max_workers, thread_name_prefix='dac-reader')
        self.running = False
        self.lock = threading.Lock()
    
    def get_active_sources(self) -> list[Source]:
        """Fetch active sources from database"""
        try:
            return list(Source.objects.filter(is_active=True).order_by('id'))
        except Exception as e:
            logger.error(f'Error fetching sources: {e}')
            return []
    
    def start_reader_for_source(self, source: Source):
        """Start a new reader thread for a source"""
        with self.lock:
            if source.code in self.active_readers:
                return
            
            stop_event = threading.Event()
            reader = SourceReader(source=source, stop_event=stop_event)
            
            self.executor.submit(reader.run)
            self.active_readers[source.code] = (reader, stop_event)
            
            logger.info(f'Started reader for source {source.code} with interval check')
    
    def stop_reader_for_source(self, source_code: str):
        """Stop reader thread for a source"""
        with self.lock:
            if source_code not in self.active_readers:
                return
            
            reader, stop_event = self.active_readers.pop(source_code)
            stop_event.set()
            
            logger.info(f'Stopped reader for source {source_code}')
    
    def stop_all_readers(self):
        with self.lock:
            for code in list(self.active_readers.keys()):
                reader, stop_event = self.active_readers.pop(code)
                stop_event.set()
                logger.info(f'Stopped reader due to global reading disable: {code}')

    def sync_readers_with_sources(self):
        """Synchronize active readers with current source configuration"""
        current_sources = self.get_active_sources()
        current_codes = {source.code for source in current_sources}
        active_codes = set(self.active_readers.keys())
        
        # Stop readers for sources that are no longer active
        for code in (active_codes - current_codes):
            self.stop_reader_for_source(code)
        
        # Start readers for new active sources
        for source in current_sources:
            if source.code not in active_codes:
                self.start_reader_for_source(source)
    
    def execute(self):
        self.running = True
        logger.info('DAC started')

        try:
            while self.running:
                settings = Settings.objects.first()
                reading_enabled = settings and settings.getJson('meta.reading_sources', False)

                if reading_enabled:
                    self.sync_readers_with_sources()
                else:
                    self.stop_all_readers()

                time.sleep(5)

        except Exception as e:
            logger.error(f'Error in main loop: {e}')
        finally:
            self.stop()
    
    def stop(self):
        """Gracefully stop all readers and shutdown executor"""
        logger.info('Stopping DAC...')
        self.running = False
        
        # Stop all active readers
        with self.lock:
            for source_code in list(self.active_readers.keys()):
                reader, stop_event = self.active_readers[source_code]
                stop_event.set()
        
        # Shutdown executor and wait for threads
        self.executor.shutdown(wait=True, cancel_futures=False)
        
        with self.lock:
            self.active_readers.clear()
        
        logger.info('DAC stopped')
    
    def ready(self):
        """Wait for interruption signal"""
        try:
            while self.running:
                time.sleep(1)
        except KeyboardInterrupt:
            logger.info('Received interrupt signal')
        finally:
            self.stop()


if __name__ == '__main__':
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    
    dac = DacReader()
    
    try:
        dac.execute()
        dac.ready()
    except KeyboardInterrupt:
        dac.stop()