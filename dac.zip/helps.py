from model import Source, Reading
from datetime import timedelta
from django.utils import timezone
from django.db import transaction
from django.db import connection
import datetime
from django.utils import timezone
import pint
import pytz
import operator
import psutil
import socket
import platform
import netifaces

OPERATORS = {
    '==': operator.eq,
    '!=': operator.ne,
    '>': operator.gt,
    '>=': operator.ge,
    '<': operator.lt,
    '<=': operator.le,
}


def get_datetime(format: str = None) -> str | datetime.datetime:
    now = timezone.now()
    try:
        match format:
            case 'date':
                return now.strftime('%Y-%m-%d')
            case 'datetime':
                return now.strftime('%Y-%m-%d %H:%M:%S')
            case 'time':
                return now.strftime('%H:%M:%S')
            case _:
                return now
    except Exception:
        # Se algo der errado, retorna string padrão
        return now.strftime('%Y-%m-%d %H:%M:%S')

def convert_by_unit(value: float, input_unit: str, output_unit: str):
    try:
        ureg = pint.UnitRegistry()
        amount = value * ureg(input_unit)
        converted = amount.to(output_unit)
        return None, converted.magnitude
    except Exception as e:
        return f"Erro na conversão: {e}", value

def convert_by_linearization(value, input_min=None, input_max=None, output_min=0, output_max=0):
    """
    Aplica linearização no valor. 
    Retorna (erro, resultado): 
      - erro: None se tudo ok, ou string com mensagem de erro
      - resultado: valor linearizado ou None em caso de erro
    """
    try:
        result_value = None

        if input_min is not None and input_max is not None:
            if input_min == input_max:
                raise ValueError("Intervalo de entrada inválido (min == max)")
            result_value = ((value - input_min) / (input_max - input_min)) * (output_max - output_min) + output_min

        elif input_min is not None and input_max is None:
            if input_min == 0:
                raise ValueError("Entrada mínima não pode ser zero")
            if value < input_min:
                result_value = output_min * (value / input_min)
            else:
                result_value = output_min + (value - input_min) * (output_min / input_min)

        elif input_min is None and input_max is not None:
            if input_max == 0:
                raise ValueError("Entrada máxima não pode ser zero")
            if value < input_max:
                result_value = output_max * (value / input_max)
            else:
                result_value = output_max + (value - input_max) * (output_max / input_max)

        else:
            raise ValueError("Ambos entrada e entrada máxima são None")

        return None, round(result_value, 3)

    except Exception as e:
        return f"Erro inesperado: {e}", None

def convertValue(source:Source, value: int | float):
    try:
        if not isinstance(source, Source):
            raise ValueError('Fonte não encontrada')
        error = None
        response = value
        function = source.getJson('meta.reading.convert.type', 'false')
        match function:
            case 'automatic':
                input_unit = source.getJson('meta.reading.convert.input_unit')
                output_unit = source.getJson('meta.reading.convert.output_unit')
                error, response = convert_by_unit(value, input_unit=input_unit, output_unit=output_unit)
            case 'manually':
                input_min = source.getJson('meta.reading.convert.input_min')
                input_max = source.getJson('meta.reading.convert.input_max')
                output_min = source.getJson('meta.reading.convert.output_min')
                output_max = source.getJson('meta.reading.convert.output_max')
                error, response = convert_by_linearization(value, input_min=input_min, input_max=input_max, output_min=output_min, output_max=output_max)
            case _:
                return None, value
        return error, response
    except Exception as e:
        print('Erro aqui',e)
        return e, None

def increment_value(previous_value: int | float = 0, new_value: int | float = 0) -> int | float:
    return sum_value(previous_value, new_value)

def apply_overwrite(current_value=None, param=None):
    return None, param

def apply_increment(current_value=None, param=None):
    return None, current_value + param

def apply_decrement(current_value=None, param=None):
    return None, current_value - param

def apply_multiply(current_value=None, param=None):
    return None, current_value * param

def apply_divide(current_value=None, param=None):
    if param == 0:
        raise ValueError("Divisão por zero")
    return None, current_value / param

def apply_reset(current_value=None, param=None):
    return None, 0

def apply_keep(current_value=None, param=None):
    return None, current_value

def apply_fixed(current_value=None, param=None):
    return None, param

def apply_discard(current_value=None, param=None):
    return True,  current_value

def apply_continue(current_value, param=None):
    return None, current_value

ACTIONS_MAP = {
    'overwrite': apply_overwrite,
    'increment': apply_increment,
    'decrement': apply_decrement,
    'multiply': apply_multiply,
    'divide': apply_divide,
    'reset': apply_reset,
    'keep': apply_keep,
    'fixed': apply_fixed,
    'discard': apply_discard,
    'continue': apply_continue,
}

def apply_evaluate_action(action_name, current_value, param=None):
    try:
        action_func = ACTIONS_MAP[action_name]
        return action_func(current_value, param)
    except KeyError:
        return f"Ação '{action_name}' não encontrada.", None
    except Exception as e:
        return str(e), None

def sum_value(left_value: int | float = 0, right_value: int | float = 0) -> int | float:
    return (left_value or 0) + (right_value or 0)

def subtract_value(left_value: int | float = 0, right_value: int | float = 0) -> int | float:
    return (left_value or 0) - (right_value or 0)
    
def subtract_absolute(left_value: int | float = 0, right_value: int | float = 0) -> int | float:
    return abs((left_value or 0) - (right_value or 0))

def get_accumulated_difference(new_value: int | float, previous_value: int | float, use_abs=False) -> int | float | None:
    try:
        if new_value is None or previous_value is None:
            return None

        if use_abs:
            return subtract_absolute(new_value, previous_value)
               
        if new_value > previous_value:
            return subtract_value(new_value, previous_value)
        else:
            if new_value == previous_value:
                return 0
            return None

    except Exception:
        return None

def evaluate_condition(left_value, operator_str, right_value):
    try:
        func = OPERATORS.get(operator_str)
        if func is None:
            raise ValueError(f"Operador não suportado: {operator_str}")
    except Exception as e:
        return e, None
    finally:
        return None, func(round(float(left_value),2), round(float(right_value),2))

def validate_or_convert(object_array:list[dict], value) -> tuple[bool, int | float, str | None]:
    try:
        error = None
        response = value

        if not isinstance(object_array, list):
            raise ValueError("Lista de validação invalida, validate_or_convert")
        
        for object_dic in object_array:
            discard = False
            true_custom_value = object_dic.get('true_custom_value')
            false_custom_value = object_dic.get('false_custom_value')
            action_true = object_dic.get('action_true')
            action_false = object_dic.get('action_false')
            error, status = evaluate_condition(value,object_dic.get('operator'), object_dic.get('value'))
            if status:
                discard, response = apply_evaluate_action(action_true, value, true_custom_value )
            else:
                discard, response = apply_evaluate_action(action_false, value, false_custom_value )

            if discard:
                return None, None
        
        return error, response
    except Exception as e:
        print(f'Erro ao tentar validar e converter valor',e)

def get_start_of_period(period: str, now=None, tz='UTC'):
    if not now:
        now = timezone.now()

    # Converte para timezone local, se necessário
    local_tz = pytz.timezone(tz)
    local_now = now.astimezone(local_tz)

    match period:
        case 'minute':
            result = local_now.replace(second=0, microsecond=0)
        case 'hour':
            result = local_now.replace(minute=0, second=0, microsecond=0)
        case 'day':
            result = local_now.replace(hour=0, minute=0, second=0, microsecond=0)
        case 'week':
            start_of_week = local_now - timedelta(days=local_now.weekday())
            result = start_of_week.replace(hour=0, minute=0, second=0, microsecond=0)
        case 'month':
            result = local_now.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
        case 'year':
            result = local_now.replace(month=1, day=1, hour=0, minute=0, second=0, microsecond=0)
        case _:
            result = local_now

    # Converte de volta para UTC antes de retornar
    return result.astimezone(pytz.UTC)

def get_ip_address():
    try:
        interfaces = netifaces.interfaces()
        for interface in interfaces:
            if interface == 'lo':
                continue
            iface = netifaces.ifaddresses(interface).get(netifaces.AF_INET)
            if iface != None:
                for link in iface:
                    return link['addr']
    except Exception as e:
        print(e)
        return None

def mac_to_hex(mac: str) -> str:
    """
    Recebe MAC com dois-pontos e devolve só o hex: AABBCCDDEEFF
    """
    return mac.replace(":", "").lower()

def get_mac_address():
    try:
        interfaces = netifaces.interfaces()
        for interface in interfaces:
            if interface == 'lo':
                continue
            iface = netifaces.ifaddresses(interface).get(netifaces.AF_LINK)
            if iface != None:
                for link in iface:
                    return link['addr']
    except Exception as e:
        print(e)
        return None
    
def get_gateway():
    try:
        gateway = netifaces.gateways()
        return gateway['default'][netifaces.AF_INET][0]
    except Exception as e:
        print(e)
        return None

def get_netmask():
    try:
        interfaces = netifaces.interfaces()
        for interface in interfaces:
            if interface == 'lo':
                continue
            iface = netifaces.ifaddresses(interface).get(netifaces.AF_INET)
            if iface != None:
                for link in iface:
                    return link['netmask']
    except Exception as e:
        print(e)
        return None


def collect_metrics()->dict:
    try:
        metadata = {}

        # METADATA BÁSICO
        try:
            metadata['cpu'] = {
                'cores_physical': psutil.cpu_count(logical=False),
                'cores_total': psutil.cpu_count(logical=True),
                'frequency': psutil.cpu_freq()._asdict() if psutil.cpu_freq() else {},
                'architecture': platform.machine(),
                'processor': platform.processor(),
                'percent': psutil.cpu_percent(interval=1),
            }
        except Exception as e:
            print(f"[DeviceProcess] Erro em cpu: {e}")
            metadata['cpu'] = {}

        try:
            mem = psutil.virtual_memory()
            metadata['memory'] = {
                'total_gb': round(mem.total / (1024 ** 3), 2),
                'used_percent': mem.percent,
                'used_gb': round(mem.used / (1024 ** 3), 2)
            }
        except Exception as e:
            print(f"[DeviceProcess] Erro em memory: {e}")
            metadata['memory'] = {}

        try:
            metadata['os'] = {
                'system': platform.system(),
                'release': platform.release(),
                'version': platform.version(),
                'hostname': socket.gethostname()
            }
        except Exception as e:
            print(f"[DeviceProcess] Erro em os: {e}")
            metadata['os'] = {}

        try:
            metadata['boot_time'] = datetime.datetime.fromtimestamp(psutil.boot_time()).isoformat()
            metadata['uptime_minutes'] = round((datetime.datetime.now() - datetime.datetime.fromtimestamp(psutil.boot_time())).total_seconds() / 60, 2)
        except Exception as e:
            print(f"[DeviceProcess] Erro em boot_time/uptime: {e}")
            metadata['boot_time'] = None
            metadata['uptime_minutes'] = None

        try:
            temps = psutil.sensors_temperatures()
            cpu_entry = None

            # Prioridade para sensores mais confiáveis
            for key in ["coretemp", "cpu-thermal", "acpitz", "gigabyte_wmi"]:
                if key in temps and temps[key]:
                    cpu_entry = temps[key]
                    break

            if cpu_entry:
                # Filtra para capturar a média e limites (caso haja)
                currents = [t.current for t in cpu_entry if hasattr(t, 'current')]
                highs = [t.high for t in cpu_entry if hasattr(t, 'high') and t.high is not None]
                criticals = [t.critical for t in cpu_entry if hasattr(t, 'critical') and t.critical is not None]

                metadata["temperature"] = {
                    "current": round(sum(currents) / len(currents), 1) if currents else 0,
                    "min": round(min(currents), 1) if currents else 0,
                    "max": round(max(currents), 1) if currents else 0,
                    "high": round(max(highs), 1) if highs else None,
                    "critical": round(max(criticals), 1) if criticals else None,
                }
            else:
                metadata["temperature"] = {}

        except Exception as e:
            print(f"[DeviceProcess] Erro em temperatura: {e}")
            metadata["temperature"] = {}

        except Exception as e:
            print(f"[DeviceProcess] Erro em temperatura: {e}")
            metadata['temperature'] = {
                'current': 0,
                'high': None,
                'critical': None
            }

        try:
            metadata['disk'] = {
                'usage': psutil.disk_usage('/')._asdict()
            }
        except Exception as e:
            print(f"[DeviceProcess] Erro em disco: {e}")
            metadata['disk'] = {}

        try:
            metadata['network'] = {
                'ip': get_ip_address(),
                'mask': get_netmask(),
                'gateway': get_gateway(),
                'mac':get_mac_address()
            }
        except Exception as e:
            print(f"[DeviceProcess] Erro em rede: {e}")
            metadata['network'] = {}

        try:
            with connection.cursor() as cursor:
                cursor.execute("SELECT pg_database_size(current_database());")
                size_bytes = cursor.fetchone()[0]
                metadata['database'] = {
                    'size_bytes': size_bytes,
                    'size_mb': round(size_bytes / (1024 ** 2), 2),
                    'deiver': 'PostgreSQL'
                }
        except Exception as e:
            print(f"[DeviceProcess] Erro em database size: {e}")
            metadata['database'] = {}

        # SALVA
        try:
            metadata['count_sources']= int(Source.objects.count());
            metadata['count_reading']= int(Reading.objects.count());
            return metadata
        except Exception as e:
            print(f"[DeviceProcess] Erro ao salvar metadata: {e}")

    except Exception as e:
        print(f"[DeviceProcess] Erro geral na coleta de status: {e}")