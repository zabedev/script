import subprocess
import threading
import logging
from rest_framework.viewsets import ModelViewSet
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework import status
from rest_framework.authtoken.views import ObtainAuthToken
from rest_framework.authtoken.models import Token
from rest_framework.permissions import IsAuthenticated
from rest_framework.views import APIView
from django.core.exceptions import ValidationError
from django.utils.timezone import now
from django.shortcuts import get_object_or_404
from django.contrib.auth import get_user_model
from database.models import Reading, Source, Settings, SourceStatus
from backend.views.serializers import ReadingSerializer, SourceSerializer,  SettingsSerializer, UserSerializer, SourceStatusSerializer, ChangePasswordSerializer
from backend.utils import decode_base64
from backend import settings
from rest_framework.authentication import TokenAuthentication

logger = logging.getLogger(__name__)

User = get_user_model()

class SettingsViewSet(ModelViewSet):
    queryset = Settings.objects.all()
    serializer_class = SettingsSerializer

    def _run_async(self, command: list):
        """Executa o comando em uma thread separada, sem bloquear a API."""
        def run():
            try:
                subprocess.run(command, check=False)
            except Exception as e:
                print("Erro executando comando:", e)

        t = threading.Thread(target=run)
        t.start()

    def get_object(self):
        settingsObject = Settings.objects.first()
        if not settingsObject:
            settingsObject = Settings.createNewSettings()
        return settingsObject

    def list(self, request, *args, **kwargs):
        settingsObject = self.get_object()
        serializer = self.get_serializer(settingsObject)
        return Response(serializer.data)

    @action(detail=False, methods=['post'], url_path='reboot')
    def reboot_system(self, request, *args, **kwargs):
        """
        POST /settings/reboot_system/
        """
        try:
            data = {"message": "Reinicialização iniciada."}
            if settings.DEBUG:
                return Response(data, status=status.HTTP_200_OK)
            else:
                self._run_async(["sudo", "reboot"])
            logger.info("Reinicialização iniciada.")
            return Response(data, status=status.HTTP_200_OK)
        except Exception as e:
            return Response({'detail': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


    @action(detail=False, methods=['post'], url_path='restart/services')
    def restart_services(self, request, *args, **kwargs):
        """
        POST /settings/restart/services/
        Reinicia todos os serviços do Supervisor.
        """
        try:
            # Executa restart em todos os serviços do Supervisor
            result = subprocess.check_output(
                ["sudo", "supervisorctl", "restart", "all"],
                text=True
            )

            logger.info(f"Supervisor restart all: {result}")

            return Response(
                {
                    "message": "Serviços reiniciados via Supervisor.",
                    "output": result
                },
                status=status.HTTP_200_OK
            )

        except subprocess.CalledProcessError as e:
            return Response(
                {"detail": f"Erro ao reiniciar serviços: {e.output}"},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )

        except Exception as e:
            return Response(
                {"detail": str(e)},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )


    @action(detail=False, methods=['put', 'patch'], url_path='update')
    def update_settings(self, request, *args, **kwargs):
        """
        PUT /settings/update_settings/
        PATCH /settings/update_settings/
        """
        settingsObject = self.get_object()
        data = request.data.copy()
        meta = data.get('meta', {})
        auto_time = meta.get('auto_restart_time', False)
        if auto_time:
            from datetime import datetime, timedelta
            try:
                dt = datetime.fromisoformat(auto_time.replace('z',''))
                meta['auto_restart_time'] = dt.strftime('%H:%M')
            except ValueError:
                pass
        data['meta'] = meta
        serializer = self.get_serializer(settingsObject, data=data, partial=(request.method == 'PATCH'))
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response(serializer.data, status=status.HTTP_200_OK)


class SourceStatusViewSet(ModelViewSet):
    queryset = SourceStatus.objects.all()
    serializer_class = SourceStatusSerializer

class SourceViweSet(ModelViewSet):
    queryset = Source.objects.all()
    serializer_class = SourceSerializer

    @action(detail=True, methods=['get'], url_path='readings')
    def get_readings(self, request, pk=None):
        """
        Retorna as leituras de uma fonte específica.
        Suporta paginação padrão do DRF (?page=1).
        """
        source = self.get_object()
        
        # Filtra pela fonte e ordena da mais recente para a mais antiga
        queryset = Reading.objects.filter(source=source.code).order_by('-created_at')

        # Otimização: Se você quiser limitar apenas às ultimas 50 para o dashboard 'live'
        # para não pesar, você pode pegar via query_param
        limit = request.query_params.get('limit',50)
        if limit:
            queryset = queryset[:int(limit)]

        # Aplica a paginação padrão configurada no settings.py (PAGE_SIZE)
        page = self.paginate_queryset(queryset)
        if page is not None:
            serializer = ReadingSerializer(page, many=True)
            return self.get_paginated_response(serializer.data)

        # Fallback se não houver paginação configurada
        serializer = ReadingSerializer(queryset, many=True)
        return Response(serializer.data)

    @action(detail=True, methods=['delete'], url_path='readings/delete-all')
    def delete_all_readings(self, request, pk=None):
        """
        Remove TODAS as leituras vinculadas a esta fonte.
        """
        source = self.get_object()
        
        # Deleta todas as leituras baseadas no código da fonte
        count, _ = Reading.objects.filter(source=source.code).delete()
        
        return Response(
            {'message': f'{count} leituras foram removidas com sucesso.'},
            status=status.HTTP_200_OK
        )
        

class ReadingViewSet(ModelViewSet):
    queryset = Reading.objects.all()
    serializer_class = ReadingSerializer 

class LogoutView(APIView):
    authentication_classes = [TokenAuthentication]
    permission_classes = [IsAuthenticated]

    def delete(self, request, *args, **kwargs):
        # apagar o token atual
        request.user.auth_token.delete()

        return Response(
            {"detail": "Logout realizado com sucesso."},
            status=status.HTTP_204_NO_CONTENT
        )


class CustomAuthToken(ObtainAuthToken):
    
    def post(self, request, *args, **kwargs):
        
        if not User.objects.filter(is_superuser=True).exists():
            User.objects.create_superuser(
                username='admin',
                password=decode_base64(settings.ADMIN_PASSWORD),
                email='admin@zabe.local'
            )

        serializer = self.serializer_class(data=request.data, context={'request': request})
        serializer.is_valid(raise_exception=True)
        user = serializer.validated_data['user']
        token, created = Token.objects.get_or_create(user=user)
        user_data = UserSerializer(user).data
        
        return Response({
            'token': token.key,
            'token_type':'Token',
            'user': user_data,
            
        })

class VerifyTokenView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request, *args, **kwargs):
        user = request.user

        if not user:
            return Response({'detail': 'Usuário não autenticado.'}, status=status.HTTP_401_UNAUTHORIZED)
        try:
            user_data = UserSerializer(user).data
            return Response({'user': user_data, 'isAuthenticated': True})
        except Exception as e:
            return Response({'detail': 'Erro ao obter usuário.'}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


class ResetPasswordView(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request, *args, **kwargs):       
        user = request.user
        user.set_password(decode_base64(settings.ADMIN_PASSWORD))
        user.save()
        return Response({'status': 'password changed'}, status=status.HTTP_200_OK)


class ChangePasswordView(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request, *args, **kwargs):
        serializer = ChangePasswordSerializer(data=request.data, context={'request': request})
        serializer.is_valid(raise_exception=True)
        user = request.user
        user.set_password(serializer.validated_data['new_password'])
        user.save()
        return Response({'status': 'password changed'}, status=status.HTTP_200_OK)