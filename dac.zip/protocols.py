from pymodbus.client import ModbusTcpClient
from pymodbus.exceptions import ModbusException
from model import Source, SourceStatus
from django.db import transaction
from django.utils import timezone
import pytz

def getDatetimeNow(tz='UTC'):
    try:
        now = timezone.now()
        local_tz = pytz.timezone(tz)
        date = now.astimezone(local_tz)
        return date.isoformat()
    except:
        return None

def getSourceStatusValue(source, default=None):
    try:
        status = SourceStatus.objects.filter(source=source).first()
        if not status:
            return default
        value = status.getJson('meta.value')
        return value if value else default
    except Exception as e:
        print(e)
        return default

def setValueForSourceStatus(source, field, value=None):
    try:
        if field is None:
            return
            
        status = SourceStatus.objects.filter(source=source).first()
        with transaction.atomic():
            status.setJson(f'meta.{field}', value)
            status.save(update_fields=['meta'])
    except Exception as e:
        print(e)
    
def setSourceStatus(source, connected=False, error=None, last_error_at=None, last_connected_at=None, value=None):
    try:
        status = SourceStatus.objects.filter(source=source).first()
        with transaction.atomic():
            if not error is None:
                status.setJson('meta.error', error)
                status.setJson('meta.last_error_at',last_error_at if last_error_at else getDatetimeNow())
                status.setJson('meta.last_connected_at','')
                status.is_connected = False
            elif not last_connected_at is None:
                status.setJson('meta.last_connected_at',last_connected_at)
                status.setJson('meta.error', '')
                status.setJson('meta.last_error_at','')
                status.is_connected = True       
            
            if not value is None:
                status.setJson('meta.value', value)

            status.save()
    except Exception as e:
        print(f'[SOURCE STATUS] {e}')

def modbusReading(source:Source):
    status = SourceStatus.objects.filter(source=source.code).first()
    try:
        if not source:
            setSourceStatus(source.code, 
                error=f'[MODBUS] Falha ao tentar estabelecer conexao, servidor não encontrado', 
            )
            return

        serverHost = source.getJson('meta.modbus.host')
        serverPort = source.getJson('meta.modbus.port', 502)
        sourceTimeout = source.getJson('meta.modbus.timeout', 3)

        client = ModbusTcpClient(
            host=serverHost, 
            port=serverPort, 
            timeout=sourceTimeout
            )
        client.connect()

        if not client.connected:
            setSourceStatus(source.code,  error=f'[MODBUS] Falha ao tentar estabelecer conexao com {serverHost}:{serverPort}')
            return

        # setSourceStatus(source.code, last_connected_at=getDatetimeNow())
  
        modbusFunctionsMap = {
            'read_holding_registers': client.read_holding_registers,
            'read_input_registers': client.read_input_registers,
            'read_coils': client.read_coils,
            'read_discrete_inputs': client.read_discrete_inputs,
            'write_coil': client.write_coil,
            'write_coils': client.write_coils,
            'write_register': client.write_register,
            'write_registers': client.write_registers
        }
        modbusDataTypesMap = {
            "int16": client.DATATYPE.INT16,
            "uint16": client.DATATYPE.UINT16,
            "int32": client.DATATYPE.INT32,
            "uint32": client.DATATYPE.UINT32,
            "int64": client.DATATYPE.INT64,
            "uint64": client.DATATYPE.UINT64,
            "float32": client.DATATYPE.FLOAT32,
            "float64": client.DATATYPE.FLOAT64,
            "string": client.DATATYPE.STRING,
            "bits": client.DATATYPE.BITS,
        }
        modbusFunctions = source.getJson('meta.modbus.functions','read_holding_registers')

        if modbusFunctions not in modbusFunctionsMap:
            setSourceStatus(source.code, error=f'[MODBUS] função {modbusFunctions} nao encontrada', )
            return None

        response = modbusFunctionsMap[modbusFunctions](
            address=int(source.getJson('meta.modbus.address')),
            count=int(source.getJson('meta.modbus.count')),
            device_id=int(source.getJson('meta.modbus.slave')),
        )

        if response.isError():
            setSourceStatus(source.code, error=f'[MODBUS] Falha ao tentar ler dados')
            return None

        setSourceStatus(source.code, last_connected_at=getDatetimeNow())
        
        modbusFormat = source.getJson('meta.modbus.format', 'int16')
        if hasattr(response, 'registers'):
            if modbusFormat and modbusFormat != 'test':
                return client.convert_from_registers(registers=response.registers, data_type=modbusDataTypesMap[modbusFormat])
            return response.registers
        elif hasattr(response, 'bits'):
            return response.bits
        else:
            setSourceStatus(source.code, error='[MODBUS] Falha ao tentar formatar dados')
            return None

    except (ModbusException, Exception) as e:
        setSourceStatus(source.code, error=f'[MODBUS] {e}')
        return None
    finally:
        try:
            client.close()
        except:
            pass
    return None