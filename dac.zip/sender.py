import logging
import datetime
import time
import threading
from server_request import RequestServer
from model import Source, SourceStatus, Reading
from rest_framework import serializers
from django.db import transaction
from protocols import setValueForSourceStatus, getDatetimeNow
import netifaces
from helps import get_ip_address, get_mac_address, collect_metrics


logger = logging.getLogger(__name__)

class SourceStatusSerializer(serializers.ModelSerializer):
    class Meta:
        model = SourceStatus
        fields = '__all__' 

class ReadingSerializer(serializers.ModelSerializer):
    class Meta:
        model = Reading
        fields = '__all__'

class SourceSerializer(serializers.ModelSerializer):
    status = serializers.SerializerMethodField()
    class Meta:
        model = Source
        fields = '__all__'
        extra_fields = ['status']
    
    def get_status(self, obj):
        try:
            status = SourceStatus.objects.filter(source=obj.code).first()
            if status:
                return SourceStatusSerializer(status).data
            return None
        except Exception as e:
            logger.error(f'Error in get_status: {e}')
            return None


class DacSender:

    def __init__(self, max_workers: int = 50):
        self.http_client = RequestServer()
        self.running = True
    
    def sync_readings(self):
        try:
            settings = Settings.objects.first()
            if not settings:
                return
            
            send_readings = settings.getJson('meta.send_readings', False)

            if not send_readings:
                return
            
            queryReading = Reading.objects.all().order_by('-id')[:300]
            reading_serializer = ReadingSerializer(queryReading, many=True)

            if not reading_serializer.data:
                return

            http_client = RequestServer()
            response = http_client.post('dac/readings', reading_serializer.data)

            if response and response.status_code and response.status_code in [200, 201]:
                try:
                    remote_list_delete = response.json()
                except Exception as e:
                    logger.error(f'Error in sync_readings: {e}, get list delete')
                    remote_list_delete = []
                finally:
                    if not remote_list_delete:
                        return
                    
                    if not isinstance(remote_list_delete, (list, dict)):
                        logger.error(f'Error in sync_readings: invalid response')
                        return
                    
                    with transaction.atomic():
                        for uid in remote_list_delete:
                            try:
                                reading = Reading.objects.filter(uid=uid).first()
                                if reading and not reading.is_open and reading.creation_type == 'historical':
                                    reading.delete()
                                    setValueForSourceStatus(reading.source, field='last_sync_at', value=getDatetimeNow())
                            except Exception as e:
                                logger.error(f'Error in sync_readings: {e}, delete reading {uid}')
            else:
                logger.error(f'Error in sync_readings invalid response {response.text}')
    
        except Exception as e:
            logger.error(f'Error in sync_readings: {e}')



    def sync_dac(self):
        try:
            settings = Settings.objects.first()
            if not settings:
                return
            
            sync_source = settings.getJson('meta.sync_source', False)

            if not sync_source:
                return
            
            http_client = RequestServer()
            querySource = Source.objects.all()           
            source_serializer = SourceSerializer(querySource, many=True)

            serializer = {
                'sources': source_serializer.data,
                'device': {
                    'mac': str(get_mac_address()),
                    'ip': str(get_ip_address()),
                    'metrics': collect_metrics()
                }
            }

            response = http_client.post('dac/update', serializer)

            if response and response.status_code and response.status_code in [200]:                
                try:
                    remote_list_update = response.json()
                                                            
                    if not isinstance(remote_list_update, (list, dict)):
                        return

                    with transaction.atomic():
                        
                        for item in remote_list_update.get('sources', []):
                            try:
                                setValueForSourceStatus(item, field='last_sync_at', value=getDatetimeNow())
                            except Exception as e:
                                logger.error(f'Error in sync_source: {e}, update last_sync_at for {item.get("source")}')

                except Exception as e:
                    logger.error(f'Error in sync_source: {e}, get list update')
            else:
                logger.error(f'Error in sync_source invalid response')
           
        except Exception as e:
            logger.error(f'Error in sync_source: {e}')
        
        
    def execute(self):
        """Main coordination loop"""
        logger.info('DAC started sender')
        try:
            while self.running:
                self.sync_dac()
                self.sync_readings()
                time.sleep(10)  # Check for configuration changes every 10 seconds
                
        except Exception as e:
            logger.error(f'Error in main loop: {e}')
        finally:
            self.stop()

    def stop(self):
        """Gracefully stop all readers and shutdown executor"""
        logger.info('Stopping DAC...')
        self.running = False    
        logger.info('DAC stopped')

    def ready(self):
        """Wait for interruption signal"""
        try:
            while True:
                time.sleep(1)
        except KeyboardInterrupt:
            logger.info('Received interrupt signal')
        finally:
            self.stop()


if __name__ == '__main__':
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    
    dac = DacSender()
    
    try:
        dac.execute()
        dac.ready()
    except KeyboardInterrupt:
        dac.stop()