import os
import environ
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent

env = environ.Env()
environ.Env.read_env( env_file = os.path.join(BASE_DIR, '.env') )

SECRET_KEY=env.str('SECRET_KEY','ua)j8kal-r7tcol$aok4f3-0heu$_ooy=#pg3ob!_13z-1_ppe')
DEBUG = env.bool('DEBUG', False)

DEFAULT_AUTO_FIELD = 'django.db.models.BigAutoField'

DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.postgresql',
        'NAME': env.str('DB_DATABASE', ''), 
        'USER': env.str('DB_USER', ''),
        'PASSWORD': env.str('DB_PASSWORD', ''),
        'HOST': env.str('DB_HOST', '127.0.0.1'),
        'PORT': env.int('DB_PORT', 5432),
        'OPTIONS': {
            'sslmode': 'prefer',
        },
    }
}

INSTALLED_APPS =( [
    'database',
])

LANGUAGE_CODE = env.str('LANGUAGE_CODE','pt-BR')
TIME_ZONE = env.str('TIME_ZONE','UTC')
USE_I18N = True
USE_L10N = True
USE_TZ = True
